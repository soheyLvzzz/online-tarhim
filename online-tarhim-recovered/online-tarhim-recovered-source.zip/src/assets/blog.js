import {
  r as React,
  j as jsx,
  c as ReactDOM,
  H as Header,
  F as Footer,
  i as initializePage,
  a as isPageTarget,
  n as navigatePage,
  u as useScrollReveal,
  p as pageHref,
} from './routes.js';

const { jsx: element, jsxs: elements } = jsx;
const { StrictMode, useState, useEffect } = React;

const featured = {
  id: 'blog-featured',
  topic: 'online-ceremony',
  title: 'چگونه مراسم آنلاین برگزار کنیم؟',
  description:
    'برگزاری محترمانه مجلس ختم و بزرگداشت به صورت آنلاین، فرصتی فراهم می‌کند تا بستگان و دوستان از هر شهر و کشوری در کنار خانوادهٔ معزا قرار بگیرند و با آرامش یاد',
  category: 'راهنمای جامع برگزاری',
  date: '۱۴ آبان ۱۴۰۵',
  time: '۷ دقیقه',
};
const articleSample = {
  topic: 'online-ceremony',
  title: 'برای مراسم آنلاین چه چیزهایی آماده کنیم؟',
  description:
    'فهرست گام به گام مدارک، اطلاعات متوفی، تصویر پرتره و از ثبت درخواست مجلس ختم آنلاین.',
  category: 'آماده سازی مراسم',
  date: '۱۲ آبان',
  time: '۵ دقیقه',
};

const latestArticles = Array.from({ length: 9 }, (_, index) => ({
  ...articleSample,
  id: `blog-article-${index + 1}`,
}));

function Reveal({ as, children, ...props }) {
  const { sectionRef, reveal } = useScrollReveal();
  return element(as, {
    ...props,
    ref: sectionRef,
    'data-blog-reveal': reveal,
    children,
  });
}

function emit(name, detail) {
  window.dispatchEvent(new CustomEvent(`tarhim:${name}`, { detail }));
}
function navigate(target) {
  if (target === 'blog' && pageTarget === 'blog') window.scrollTo({ top: 0 });
  else if (isPageTarget(target)) navigatePage(target);
  else emit('navigate', { target });
}
function footerNavigate(target) {
  if (target === 'ceremonies') navigatePage('live');
  if (['services', 'archive', 'plans'].includes(target))
    navigatePage('home', target);
}

function ReadArticle({ onRead }) {
  const [showNotice, setShowNotice] = useState(false);
  return elements('div', {
    className: 'blog-read',
    children: [
      elements('button', {
        type: 'button',
        className: 'blog-read__button',
        onClick: () => {
          onRead();
          setShowNotice(true);
        },
        children: [
          'مطالعه مقاله',
          element('img', {
            src: './assets/memorial/post/enter-arrow.svg',
            alt: '',
          }),
        ],
      }),
      showNotice &&
        element('p', {
          className: 'blog-read__notice',
          role: 'status',
          children: 'صفحهٔ این مقاله هنوز منتشر نشده است.',
        }),
    ],
  });
}

function BlogHero() {
  return elements(Reveal, {
    as: 'section',
    className: 'blog-hero',
    'aria-labelledby': 'blog-title',
    children: [
      element('img', {
        className: 'blog-hero__backdrop',
        src: './assets/memorial/hero-background.png',
        alt: '',
      }),
      elements('div', {
        className: 'blog-container blog-hero__copy',
        children: [
          element('p', {
            className: 'blog-hero__eyebrow',
            children: 'مجله و راهنمای همراهی خانواده‌ها',
          }),
          element('h1', {
            id: 'blog-title',
            children: 'بلاگ و راهنمای برگزاری مراسم یادبود',
          }),
          element('p', {
            className: 'blog-hero__intro',
            children:
              'مطالب کاربردی درباره آداب سوگواری مجازی، آماده‌سازی مراسم آنلاین و راه‌های محترمانه برای زنده نگه داشتن یاد عزیزان از هر فاصله‌ای.',
          }),
        ],
      }),
    ],
  });
}

function FeaturedArticle({ isPost = false }) {
  return element(Reveal, {
    as: 'section',
    className: 'blog-container blog-featured',
    'aria-labelledby': 'blog-featured-title',
    children: elements('article', {
      className: 'blog-featured__card',
      children: [
        element('img', {
          className: 'blog-featured__image',
          src: './assets/blog/featured.png',
          alt: '',
          width: 887,
          height: 448,
        }),
        elements('div', {
          className: 'blog-featured__copy',
          children: [
            elements('div', {
              className: 'blog-featured__tags',
              children: [
                elements('span', {
                  className: 'blog-featured__badge',
                  children: [
                    element('span', { 'aria-hidden': 'true', children: '★' }),
                    'مقاله منتخب',
                  ],
                }),
                !isPost && element('span', { children: featured.category }),
              ],
            }),
            element(isPost ? 'h1' : 'h2', {
              id: 'blog-featured-title',
              children: featured.title,
            }),
            element('p', { children: featured.description }),
            elements('div', {
              className: 'blog-featured__footer',
              children: [
                elements('div', {
                  className: 'blog-featured__meta',
                  children: [
                    elements('span', {
                      children: [
                        element('img', {
                          src: './assets/live/calendar.svg',
                          alt: '',
                        }),
                        featured.date,
                      ],
                    }),
                    elements('span', {
                      children: [
                        element('img', {
                          src: './assets/live/clock.svg',
                          alt: '',
                        }),
                        `زمان مطالعه : ${featured.time}`,
                      ],
                    }),
                  ],
                }),
                !isPost &&
                  elements('a', {
                    className: 'blog-read__button',
                    href: pageHref('blogGuide'),
                    onClick: () => emit('read-news', { id: featured.id }),
                    children: [
                      'مطالعه مقاله',
                      element('img', {
                        src: './assets/memorial/post/enter-arrow.svg',
                        alt: '',
                      }),
                    ],
                  }),
              ],
            }),
          ],
        }),
      ],
    }),
  });
}

function ArticleCard({ article }) {
  return elements('article', {
    className: 'blog-card',
    children: [
      elements('div', {
        className: 'blog-card__media',
        children: [
          element('img', {
            src: './assets/blog/card.png',
            alt: '',
            width: 433,
            height: 300,
            loading: 'lazy',
          }),
          element('span', {
            className: 'blog-card__category',
            children: article.category,
          }),
        ],
      }),
      elements('div', {
        className: 'blog-card__copy',
        children: [
          elements('p', {
            className: 'blog-card__meta',
            children: [
              element('span', { children: article.date }),
              element('span', { 'aria-hidden': 'true', children: '•' }),
              element('span', { children: `${article.time} مطالعه` }),
            ],
          }),
          element('h3', { children: article.title }),
          element('p', {
            className: 'blog-card__description',
            children: article.description,
          }),
          element(ReadArticle, {
            onRead: () => emit('read-news', { id: article.id }),
          }),
        ],
      }),
    ],
  });
}

function BlogListing() {
  return elements('main', {
    children: [
      element(BlogHero, {}),
      element(FeaturedArticle, {}),
      elements(Reveal, {
        as: 'section',
        className: 'blog-container blog-latest',
        'aria-labelledby': 'blog-latest-title',
        children: [
          elements('header', {
            className: 'blog-latest__heading',
            children: [
              element('h2', {
                id: 'blog-latest-title',
                children: 'تازه ترین مقالات',
              }),
              element('span', {
                className: 'blog-latest__divider',
                'aria-hidden': 'true',
              }),
              element('p', {
                children:
                  'گزیده راهنماهای عملی برای خانواده‌ها و مهمانان مراسم',
              }),
            ],
          }),
          element('div', {
            className: 'blog-grid',
            children: latestArticles.map((article) =>
              element(ArticleCard, { article }, article.id),
            ),
          }),
        ],
      }),
    ],
  });
}

const intro = {
  id: 'guide-intro',
  title: 'مقدمه و اهمیت همراهی آنلاین',
  paragraphs: [
    'از دست دادن عزیزان یکی از سنگین‌ترین تجربه‌های زندگی است و در این روزها، حضور اقوام، دوستان و آشنایان در کنار خانوادهٔ داغدار مرهمی بزرگ به شمار می‌آید. با این حال، پراکندگی جغرافیایی، سکونت بستگان در شهرها یا کشورهای دیگر و دشواری سفر برای سالمندان، گاه مانع از حضور فیزیکی همهٔ دوستداران در مجلس ختم می‌شود.',
    'برگزاری یک مراسم یادبود آنلاین باوقار، این فاصله‌ها را از میان برمی‌دارد. در ادامه، در پنج مرحلهٔ روشن و آرام مرور می‌کنیم که چگونه بدون دغدغهٔ فنی، مجلسی محترمانه و درخور شأن عزیز خود برگزار نمایید.',
  ],
};
const guideSections = [
  {
    id: 'guide-schedule',
    title: 'زمان و قالب مراسم را مشخص کنید',
    paragraphs: [
      'نخستین گام، انتخاب روز و ساعتی است که بیشترین هماهنگی را با شرایط خانواده و بستگان مقیم در شهرها یا کشورهای دیگر داشته باشد. اگر بخشی از مهمانان در خارج از کشور حضور دارند، معمولاً انتخاب ساعت‌های عصر به وقت ایران (برای نمونه ساعت ۱۸ تا ۱۹:۳۰) امکان همراهی هم‌زمان بیشتری را فراهم می‌کند.',
      'در همین مرحله، قالب کلی برنامه را نیز مشخص کنید. اینکه مجلس شامل تلاوت آیاتی از قرآن کریم، سخنرانی کوتاه، مداحی و ذکر مصیبت یا خاطره‌گویی چند تن از نزدیکان باشد. مدت‌زمان ۶۰ تا ۷۵ دقیقه برای یک مراسم آنلاین، ریتمی آرام، محترمانه و بدون خستگی برای مهمانان ایجاد می‌کند.',
    ],
  },
  {
    id: 'guide-photos',
    title: 'عکس‌ها و محتوای یادبود را آماده کنید.',
    paragraphs: [
      'تصویر شاخصی که در قاب قوسی صفحهٔ مراسم نمایش داده می‌شود، نخستین جلوهٔ بصری برای مهمانان است. پرتره‌ای روشن، آرام و باکیفیت از چهرهٔ عزیز خود انتخاب کنید که یادآور لبخند و وقار ایشان در ذهن اطرافیان باشد. همچنین تاریخ دقیق تولد و وفات و یک متن کوتاه دوخطی برای معرفی ایشان آماده نمایید.',
      'اگر تمایل دارید در بخشی از مراسم کلیپ کوتاهی از خاطرات پخش شود، بین ۱۰ تا ۱۵ عکس از دوره‌های مختلف زندگی ایشان را با رعایت حریم خصوصی افراد حاضر در تصاویر گردآوری کنید تا با نغمه‌ای ملایم و محترمانه تدوین شود.',
    ],
  },
  {
    id: 'guide-invitation',
    title: 'لینک مراسم را برای مهمانان بفرستید.',
    paragraphs: [
      'پس از ثبت مشخصات مراسم در آنلاین ترحیم، یک صفحهٔ اختصاصی به همراه لینک مستقیم ورود و کارت دعوت دیجیتال در اختیار شما قرار می‌گیرد. مهم‌ترین ویژگی این لینک آن است که مهمانان با تلفن همراه، تبلت یا رایانه و تنها با یک لمس ساده، بدون نیاز به نصب هیچ نرم‌افزاری وارد مجلس می‌شوند.',
      'پیشنهاد می‌کنیم دعوت‌نامه و لینک ورود را دست‌کم ۲۴ تا ۴۸ ساعت پیش از شروع مراسم از طریق پیامک و پیام‌رسان‌ها برای اقوام و آشنایان ارسال کنید و در متن پیام، تاریخ و ساعت دقیق شروع را به‌صورت روشن بنویسید.',
    ],
  },
  {
    id: 'guide-equipment',
    title: 'صدا، تصویر و اتصال را پیش از مراسم بررسی کنید.',
    paragraphs: [
      'کیفیت و وضوح صدا در انتقال حس معنویت مراسم نقش کلیدی دارد. حدود ۲۰ تا ۳۰ دقیقه پیش از ساعت رسمی شروع، به همراه کارشناس پشتیبانی آنلاین ترحیم وارد اتاق پخش شوید تا بلندی صدا، وضوح میکروفون و کادر دوربین بررسی شود.',
      'اگر خانواده از منزل در پخش زنده حضور دارند، قرار دادن دوربین در ارتفاع هم‌سطح چشم و اطمینان از شارژ کامل دستگاه یا اتصال به برق، از هرگونه وقفه در میانهٔ برنامه جلوگیری می‌کند. تیم فنی ما نیز در تمام لحظات بر پایداری پخش نظارت دارد.',
    ],
  },
  {
    id: 'guide-host',
    title: 'در زمان برگزاری وارد مراسم شوید و مهمانان را راهنمایی کنید.',
    paragraphs: [
      'پنج دقیقه پیش از ساعت اعلام‌شده، تالار آنلاین با پخش نوای آرام قرآن و نمایش قاب یادبود گشوده می‌شود. مجری مراسم ضمن خیرمقدم به حاضران، به‌صورت محترمانه شیوهٔ ثبت پیام تسلیت، قرائت فاتحه و نوشتن دل‌نوشته در دفتر یادبود دیجیتال را به مهمانان یادآوری می‌کند.',
      'در پایان مجلس نیز یکی از اعضای خانواده می‌تواند در چند جمله از حضور و همدلی همهٔ عزیزانی که از راه دور یا نزدیک همراه بوده‌اند، قدردانی کند. پس از اتمام پخش زنده، صفحهٔ یادبود و تمامی پیام‌های محبت‌آمیز ثبت‌شده برای همیشه در دسترس خانواده باقی می‌ماند.',
    ],
  },
];
const checklist = [
  'ارسال پیام یادآوری: لینک مستقیم ورود به مراسم را یک ساعت مانده به شروع، دوباره برای گروه‌های خانوادگی و مهمانان اصلی بازفرستید.',
  'هماهنگی نوبت سخنرانان: با مجری برنامه، قاری و یکی از اعضای خانواده که قرار است از طرف بازماندگان خیرمقدم بگوید، ترتیب و زمان صحبت را هماهنگ کنید.',
  'آماده‌سازی محیط آرام: در مکانی ساکت با نور ملایم روبه‌رو مستقر شوید و تلفن‌های همراه اطراف را در حالت بی‌صدا قرار دهید تا تمرکز جلسه حفظ شود.',
];

const guideLinks = [
  intro,
  ...guideSections.slice(0, 3),
  { id: 'guide-checklist', title: 'مرور نهایی پیش از مراسم' },
  ...guideSections.slice(3),
];

function sectionHref(id) {
  const url = new URL(window.location.href);
  url.hash = id;
  return url.href;
}

function GuideContents() {
  const [active, setActive] = useState(
    () =>
      guideLinks.find((item) => '#' + item.id === window.location.hash)?.id ??
      intro.id,
  );
  useEffect(() => {
    const update = () =>
      setActive(
        guideLinks.find((item) => '#' + item.id === window.location.hash)?.id ??
          intro.id,
      );
    window.addEventListener('hashchange', update);
    return () => window.removeEventListener('hashchange', update);
  }, []);

  return elements('aside', {
    className: 'guide-contents',
    children: [
      element('h2', {
        className: 'guide-rule-heading',
        children: 'در این مقاله',
      }),
      element('nav', {
        'aria-label': 'فهرست بخش‌های مقاله',
        children: element('ul', {
          children: guideLinks.map((item) =>
            element(
              'li',
              {
                children: element('a', {
                  href: sectionHref(item.id),
                  'aria-current': active === item.id ? 'location' : undefined,
                  children: item.title,
                }),
              },
              item.id,
            ),
          ),
        }),
      }),
      elements('div', {
        className: 'guide-contents__support',
        children: [
          elements('p', {
            children: [
              'پاسخگویی سریع تلفنی',
              element('a', {
                href: 'tel:02188665157',
                dir: 'ltr',
                children: '۰۲۱ - ۸۸۶۶۵۱۵۷',
              }),
            ],
          }),
          elements('a', {
            className: 'guide-contents__request',
            href: pageHref('request'),
            children: [
              'درخواست مراسم',
              element('img', {
                src: './assets/memorial/post/enter-arrow.svg',
                alt: '',
              }),
            ],
          }),
        ],
      }),
    ],
  });
}

function GuideChecklist() {
  return elements('aside', {
    id: 'guide-checklist',
    className: 'guide-checklist',
    'aria-labelledby': 'guide-checklist-title',
    children: [
      elements('div', {
        className: 'guide-checklist__heading',
        children: [
          elements('h3', {
            id: 'guide-checklist-title',
            children: [
              element('img', {
                src: './assets/blog/guide-checklist.svg',
                alt: '',
                width: 32,
                height: 32,
              }),
              'پیش از مراسم',
            ],
          }),
          element('span', { children: 'مرور نهایی (سه مورد)' }),
        ],
      }),
      element('p', {
        children:
          'یک ساعت پیش از آغاز برنامه، این سه مورد کوتاه را به همراه خانواده مرور فرمایید.',
      }),
      element('ol', {
        children: checklist.map((text, index) =>
          elements(
            'li',
            {
              children: [
                element('span', {
                  'aria-hidden': 'true',
                  children: `${(index + 1).toLocaleString('fa-IR')}.`,
                }),
                text,
              ],
            },
            text,
          ),
        ),
      }),
    ],
  });
}

function GuideSection({ section, index }) {
  const isIntro = index === undefined;
  return elements(Reveal, {
    as: 'section',
    id: section.id,
    className: isIntro ? 'guide-intro' : 'guide-section',
    'aria-label': isIntro ? section.title : undefined,
    children: [
      !isIntro &&
        elements('h2', {
          children: [
            element('span', {
              className: 'guide-section__number',
              children: `${(index + 1).toLocaleString('fa-IR')}.`,
            }),
            section.title,
          ],
        }),
      ...section.paragraphs.map((text) =>
        element('p', { children: text }, text),
      ),
      index === 2 && element(GuideChecklist, {}),
    ],
  });
}

function RelatedArticles({ currentArticle }) {
  const related = latestArticles
    .filter(
      (item) =>
        item.id !== currentArticle.id && item.topic === currentArticle.topic,
    )
    .slice(0, 3);
  if (!related.length) return null;
  return elements(Reveal, {
    as: 'section',
    className: 'blog-container guide-related',
    'aria-labelledby': 'guide-related-title',
    children: [
      elements('header', {
        children: [
          element('h2', {
            id: 'guide-related-title',
            className: 'guide-rule-heading',
            children: 'مطالب مرتبط',
          }),
          elements('a', {
            href: pageHref('blog'),
            children: [
              'مشاهده همه مقالات بلاگ',
              element('img', {
                src: './assets/memorial/post/enter-arrow.svg',
                alt: '',
              }),
            ],
          }),
        ],
      }),
      element('div', {
        className: 'blog-grid',
        children: related.map((item) =>
          element(ArticleCard, { article: item }, item.id),
        ),
      }),
    ],
  });
}

function ArticleGuide() {
  return elements('main', {
    className: 'blog-guide',
    children: [
      element(FeaturedArticle, { isPost: true }),
      elements('div', {
        className: 'blog-container guide-layout',
        children: [
          element(GuideContents, {}),
          elements('article', {
            className: 'guide-body',
            'aria-labelledby': 'blog-featured-title',
            children: [
              element(GuideSection, { section: intro }),
              ...guideSections.map((section, index) =>
                element(GuideSection, { section, index }, section.id),
              ),
            ],
          }),
        ],
      }),
      element(RelatedArticles, { currentArticle: featured }),
    ],
  });
}

function BlogPage() {
  return elements('div', {
    className: 'blog-page',
    children: [
      element(Header, { onNavigate: navigate, currentTarget: 'blog' }),
      element(pageTarget === 'blogGuide' ? ArticleGuide : BlogListing, {}),
      element(Footer, {
        onQuickLink: footerNavigate,
        onService: (serviceId) => emit('service-details', { serviceId }),
        onSocial: (platform) => emit('social', { platform }),
      }),
    ],
  });
}

const root = document.getElementById('root');
const pageTarget = root.dataset.page === 'blogGuide' ? 'blogGuide' : 'blog';
initializePage(pageTarget);
ReactDOM.createRoot(root).render(
  element(StrictMode, { children: element(BlogPage, {}) }),
);
