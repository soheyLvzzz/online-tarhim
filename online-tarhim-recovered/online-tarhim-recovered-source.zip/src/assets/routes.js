const hr = [
  { target: 'home', label: 'صفحه اصلی' },
  { target: 'live', label: 'مراسم های درحال اجرا' },
  { target: 'memorial', label: 'صفحه یادبود' },
  { target: 'request', label: 'درخواست برگزاری مجلس' },
  { target: 'contact', label: 'تماس با ما' },
  { target: 'blog', label: 'بلاگ' },
];
function Mr({
  onNavigate: _,
  phoneIconSrc: Z = './assets/phone.svg',
  currentTarget: p = 'home',
}) {
  const [y, D] = ru.useState(!1),
    H = ru.useRef(null),
    dl = ru.useRef(null);
  ru.useEffect(() => {
    const J = (q) => {
        H.current?.contains(q.target) || D(!1);
      },
      Sl = (q) => {
        q.key === 'Escape' && y && (D(!1), dl.current?.focus());
      },
      Y = window.matchMedia('(max-width: 767px)'),
      S = () => D(!1);
    return (
      document.addEventListener('pointerdown', J),
      document.addEventListener('keydown', Sl),
      Y.addEventListener('change', S),
      () => {
        (document.removeEventListener('pointerdown', J),
          document.removeEventListener('keydown', Sl),
          Y.removeEventListener('change', S));
      }
    );
  }, [y]);
  const zl = (J) => {
    (D(!1), _(J));
  };
  return B.jsxs('header', {
    ref: H,
    'data-menu-open': y,
    onBlur: (J) => {
      J.currentTarget.contains(J.relatedTarget) || D(!1);
    },
    className: 'site-header',
    lang: 'fa',
    dir: 'rtl',
    'data-node-id': '4:20',
    children: [
      B.jsxs('button', {
        className: 'site-header__brand',
        type: 'button',
        onClick: () => zl('home'),
        'aria-label': 'آنلاین ترحیم، صفحه اصلی',
        children: [
          B.jsx('span', {
            className: 'site-header__logo',
            children: B.jsx('img', { src: './assets/logo.png', alt: '' }),
          }),
          B.jsxs('span', {
            className: 'site-header__brand-copy',
            children: [
              B.jsx('strong', { children: 'آنلاین ترحیم' }),
              B.jsx('span', { children: 'برگزاری مجالس ترحیم به صورت انلاین' }),
            ],
          }),
        ],
      }),
      B.jsxs('button', {
        ref: dl,
        className: 'site-header__menu-toggle',
        type: 'button',
        'aria-label': y ? 'بستن منوی اصلی' : 'باز کردن منوی اصلی',
        'aria-expanded': y,
        'aria-controls': 'header-mobile-menu',
        onClick: () => D((J) => !J),
        children: [B.jsx('span', {}), B.jsx('span', {}), B.jsx('span', {})],
      }),
      B.jsxs('div', {
        id: 'header-mobile-menu',
        className: 'site-header__menu-panel',
        children: [
          B.jsx('nav', {
            className: 'site-header__navigation',
            'aria-label': 'منوی اصلی',
            children: hr.map(({ target: J, label: Sl }) =>
              B.jsx(
                'button',
                {
                  type: 'button',
                  onClick: () => zl(J),
                  'aria-current': J === p ? 'page' : void 0,
                  children: Sl,
                },
                J,
              ),
            ),
          }),
          B.jsxs('a', {
            onClick: () => D(!1),
            className: 'site-header__phone',
            href: 'tel:02188665157',
            'aria-label': 'تماس با شمارهٔ ۰۲۱۸۸۶۶۵۱۵۷',
            dir: 'ltr',
            children: [
              B.jsx('span', {
                className: 'site-header__phone-icon',
                children: Z && B.jsx('img', { src: Z, alt: '' }),
              }),
              B.jsx('bdi', { children: '021 - 88665157' }),
            ],
          }),
        ],
      }),
    ],
  });
}
function gr() {
  const _ = ru.useRef(null),
    [Z, p] = ru.useState('visible');
  return (
    ru.useEffect(() => {
      const y = _.current,
        D = window.matchMedia('(prefers-reduced-motion: reduce)');
      if (!y || D.matches || !('IntersectionObserver' in window)) return;
      let H = !1;
      p('pending');
      const dl = new IntersectionObserver(
        ([Sl]) => {
          !H && Sl?.isIntersecting && (p('entered'), dl.disconnect());
        },
        { threshold: 0.12 },
      );
      dl.observe(y);
      const zl = () => {
        ((H = !0), dl.disconnect(), p('visible'));
      };
      (y.addEventListener('pointerdown', zl, { capture: !0 }),
        y.addEventListener('focusin', zl, { capture: !0 }));
      const J = () => {
        D.matches && zl();
      };
      return (
        D.addEventListener('change', J),
        () => {
          (dl.disconnect(),
            y.removeEventListener('pointerdown', zl, { capture: !0 }),
            y.removeEventListener('focusin', zl, { capture: !0 }),
            D.removeEventListener('change', J));
        }
      );
    }, []),
    { sectionRef: _, reveal: Z }
  );
}
const Sr = [
    { id: 'ceremonies', label: 'مراسم ها' },
    { id: 'services', label: 'خدمات' },
    { id: 'archive', label: 'آرشیو مجالس' },
    { id: 'plans', label: 'پلن ها' },
  ],
  Tr = [
    { id: 'ceremony', label: 'برگزاری مراسم' },
    { id: 'poster', label: 'طراحی یادبود' },
    { id: 'live', label: 'پخش انلاین' },
    { id: 'video', label: 'تدوین ویدیو' },
  ];
function Ur({ onQuickLink: _, onService: Z, onSocial: p }) {
  const { sectionRef: y, reveal: D } = gr();
  return B.jsxs('footer', {
    ref: y,
    className: 'site-footer',
    lang: 'fa',
    dir: 'rtl',
    'data-node-id': '42:507',
    'data-reveal': D,
    children: [
      B.jsxs('div', {
        className: 'site-footer__brand',
        children: [
          B.jsx('span', {
            className: 'site-footer__logo',
            children: B.jsx('img', { src: './assets/logo.png', alt: '' }),
          }),
          B.jsxs('div', {
            className: 'site-footer__brand-copy',
            children: [
              B.jsx('strong', { children: 'آنلاین ترحیم' }),
              B.jsx('p', {
                children:
                  'برگزاری مراسم ترحیم و یادبود، با احترام به خاطره‌ها و همراهی عزیزان.',
              }),
            ],
          }),
        ],
      }),
      B.jsxs('div', {
        className: 'site-footer__columns',
        children: [
          B.jsxs('nav', {
            className: 'site-footer__column',
            'aria-labelledby': 'footer-quick-title',
            children: [
              B.jsx('h2', {
                id: 'footer-quick-title',
                children: 'دسترسی سریع',
              }),
              B.jsx('ul', {
                children: Sr.map((H) =>
                  B.jsx(
                    'li',
                    {
                      children: B.jsx('button', {
                        className: 'site-footer__link',
                        type: 'button',
                        onClick: () => _(H.id),
                        children: H.label,
                      }),
                    },
                    H.id,
                  ),
                ),
              }),
            ],
          }),
          B.jsxs('nav', {
            className: 'site-footer__column',
            'aria-labelledby': 'footer-services-title',
            children: [
              B.jsx('h2', {
                id: 'footer-services-title',
                children: 'خدمات ما',
              }),
              B.jsx('ul', {
                children: Tr.map((H) =>
                  B.jsx(
                    'li',
                    {
                      children: B.jsx('button', {
                        className: 'site-footer__link',
                        type: 'button',
                        onClick: () => Z(H.id),
                        children: H.label,
                      }),
                    },
                    H.id,
                  ),
                ),
              }),
            ],
          }),
          B.jsxs('div', {
            className: 'site-footer__column site-footer__contact',
            children: [
              B.jsx('h2', { children: 'ارتباط با ما' }),
              B.jsxs('p', {
                children: [
                  'تلفن : ',
                  B.jsx('a', {
                    href: 'tel:09157362755',
                    children: B.jsx('bdi', {
                      dir: 'ltr',
                      children: '09157362755',
                    }),
                  }),
                ],
              }),
              B.jsxs('p', {
                children: [
                  'ایمیل : ',
                  B.jsx('a', {
                    href: 'mailto:online.tarhim@gmail.com',
                    children: B.jsx('bdi', {
                      dir: 'ltr',
                      children: 'online.tarhim@gmail.com',
                    }),
                  }),
                ],
              }),
              B.jsxs('div', {
                className: 'site-footer__socials',
                children: [
                  B.jsx('button', {
                    className: 'site-footer__social',
                    type: 'button',
                    'aria-label': 'اینستاگرام آنلاین ترحیم',
                    onClick: () => p('instagram'),
                    children: B.jsx('img', {
                      src: './assets/footer-instagram.svg',
                      alt: '',
                    }),
                  }),
                  B.jsx('button', {
                    className: 'site-footer__social',
                    type: 'button',
                    'aria-label': 'واتساپ آنلاین ترحیم',
                    onClick: () => p('whatsapp'),
                    children: B.jsx('img', {
                      src: './assets/footer-whatsapp.svg',
                      alt: '',
                    }),
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
      B.jsx('p', {
        className: 'site-footer__copyright',
        children:
          'آنلاین ترحیم © 1399 قدرت گرفته از تیم جوان شرکت آریانا و با افتخار محصولی ایرانی',
      }),
    ],
  });
}
const Er = { file: 'index.html', slug: 'صفحه-اصلی' },
  br = { file: 'live.html', slug: 'مراسم-های-درحال-برگزاری' },
  _r = { file: 'memorial.html', slug: 'صفحه-یادبود' },
  zr = { file: 'request.html', slug: 'درخواست-برگزاری-مجالس' },
  Or = { file: 'contact.html', slug: 'تماس-با-ما' },
  Nr = { file: 'memorial-post.html', slug: 'یادبود-علی-اکبر-رحیمی' },
  fd = {
    home: Er,
    live: br,
    memorial: _r,
    request: zr,
    contact: Or,
    memorialPost: Nr,
    blog: { file: 'blog.html', slug: 'بلاگ' },
    blogGuide: {
      file: 'blog-guide.html',
      slug: 'راهنمای-برگزاری-مراسم-آنلاین',
    },
  };
function Rr(_) {
  return Object.hasOwn(fd, _);
}
function id(_, Z = '', p = window) {
  const y = new URL(`${fd[_].slug}/`, p.document.baseURI);
  return ((y.hash = Z), y.href);
}
function Cr(_, Z = window) {
  const p = Z.document;
  let y = p.querySelector('base');
  const D = new URL(y?.getAttribute('href') || './', Z.location.href);
  (y || ((y = p.createElement('base')), p.head.prepend(y)), (y.href = D.href));
  const H = new URL(id(_, Z.location.hash, Z));
  ((H.search = Z.location.search),
    Z.location.href !== H.href &&
      Z.history.replaceState(Z.history.state, '', H.href));
}
function Hr(_, Z = '') {
  window.location.assign(id(_, Z));
}
export {
  Ur as F,
  Mr as H,
  or as R,
  Rr as a,
  dr as b,
  Dr as c,
  Ar as d,
  Cr as i,
  B as j,
  Hr as n,
  id as p,
  ru as r,
  gr as u,
};
