function _t({ name: e, label: t, icon: n, options: r, required: o = !0 }) {
  const { control: s } = Ar(),
    i = `request-${e}`;
  return g.jsx(Er, {
    name: e,
    control: s,
    rules: {
      validate: (a) =>
        (!o && !a) || r.includes(a) || `لطفاً ${t} را انتخاب کنید.`,
    },
    render: ({ field: a, fieldState: c }) =>
      g.jsxs('div', {
        className: 'request-select-field',
        children: [
          g.jsxs('label', {
            id: `${i}-label`,
            htmlFor: i,
            children: [
              t,
              ' ',
              o && g.jsx('em', { 'aria-hidden': 'true', children: '*' }),
            ],
          }),
          g.jsxs(Au, {
            dir: 'rtl',
            name: a.name,
            value: a.value,
            onValueChange: a.onChange,
            required: o,
            children: [
              g.jsxs(Ou, {
                id: i,
                ref: a.ref,
                onBlur: a.onBlur,
                className: 'request-control request-select',
                'aria-labelledby': `${i}-label`,
                'aria-invalid': c.invalid || void 0,
                'aria-describedby': c.error ? `${i}-error` : void 0,
                children: [
                  g.jsx('img', { src: `./assets/request/${n}.svg`, alt: '' }),
                  g.jsx('span', {
                    className: 'request-select__value',
                    children: g.jsx(Tu, { placeholder: 'انتخاب کنید' }),
                  }),
                  g.jsx(Du, {
                    asChild: !0,
                    children: g.jsx('img', {
                      className: 'request-select__chevron',
                      src: './assets/request/select-chevron.svg',
                      alt: '',
                    }),
                  }),
                ],
              }),
              g.jsx(ku, {
                children: g.jsx(Mu, {
                  className: 'request-select-menu',
                  position: 'popper',
                  sideOffset: 8,
                  align: 'start',
                  collisionPadding: 16,
                  dir: 'rtl',
                  children: g.jsx(qu, {
                    className: 'request-select-menu__viewport',
                    children: r.map((u) =>
                      g.jsxs(
                        Ku,
                        {
                          className: 'request-select-menu__option',
                          value: u,
                          children: [
                            g.jsx(Yu, { children: u }),
                            g.jsx(Xu, {
                              className: 'request-select-menu__check',
                              'aria-hidden': 'true',
                              children: '✓',
                            }),
                          ],
                        },
                        u,
                      ),
                    ),
                  }),
                }),
              }),
            ],
          }),
          c.error &&
            g.jsx('span', {
              className: 'request-field-error',
              id: `${i}-error`,
              children: c.error.message,
            }),
        ],
      }),
  });
}
function Ai({ name: e }) {
  return g.jsx('img', { src: `./assets/request/${e}.svg`, alt: '' });
}
function De({
  name: e,
  label: t,
  icon: n,
  placeholder: r,
  type: o = 'text',
  required: s,
  autoComplete: i,
  fullWidth: a,
  rules: c,
}) {
  const { control: u } = Ar();
  return g.jsx(Er, {
    name: e,
    control: u,
    rules: c,
    render: ({ field: h, fieldState: d }) =>
      g.jsxs('label', {
        htmlFor: `request-${e}`,
        className: a ? 'request-field--wide' : void 0,
        children: [
          t,
          ' ',
          s && g.jsx('em', { children: '*' }),
          g.jsxs('span', {
            className: 'request-control',
            children: [
              g.jsx(Ai, { name: n }),
              g.jsx('input', {
                ...h,
                id: `request-${e}`,
                type: o,
                required: s,
                autoComplete: i,
                placeholder: r,
                inputMode: o === 'tel' ? 'tel' : void 0,
                maxLength: e === 'customerName' ? 120 : void 0,
                onInput: (v) => h.onChange(v.currentTarget.value),
                onAnimationStart: (v) => {
                  v.animationName === 'request-autofill-start' &&
                    h.onChange(v.currentTarget.value);
                },
                'aria-invalid': d.invalid || void 0,
                'aria-describedby': d.error ? `request-${e}-error` : void 0,
              }),
            ],
          }),
          d.error &&
            g.jsx('span', {
              className: 'request-field-error',
              id: `request-${e}-error`,
              children: d.error.message,
            }),
        ],
      }),
  });
}
const Qo = ['در قید حیات', 'فوت کرده‌اند'],
  Ju = ['یادبود', 'سوم', 'هفتم', 'چهلم', 'سالگرد'],
  ef = [
    'لطفا اطلاعات تماس و ارتباط خود با متوفی را وارد کنید تا کارشناسان ما بتوانند هماهنگی های لازم را انجام دهند .',
    'اطلاعات متوفی و بستگان ایشان را وارد کنید.',
    'نوع مراسم و اطلاعات مربوط به درگذشت و مراسم را وارد کنید.',
    'در صورت تمایل، شرح حالی از زندگی متوفی بنویسید.',
  ];
function tf({ step: e, onContinue: t, onBack: n, onEdit: r }) {
  const [o, s] = f.useState(''),
    { control: i, handleSubmit: a } = Ar(),
    c = Cr({ control: i, name: 'deathLocation' }),
    u = f.useRef(null),
    h = f.useRef(e);
  return (
    f.useEffect(() => {
      h.current !== e && ((h.current = e), u.current?.focus());
    }, [e]),
    g.jsxs('form', {
      className: 'request-form request-panel',
      noValidate: !0,
      onSubmit: a(() => {
        (s(e === 4 ? 'فرم آزمایشی تکمیل شد. اطلاعاتی ارسال نشده است.' : ''),
          t());
      }),
      children: [
        g.jsxs('header', {
          className: 'request-form__header',
          children: [
            g.jsxs('small', {
              children: ['مرحله ', e.toLocaleString('fa-IR'), ' از ۴'],
            }),
            g.jsxs('h2', {
              ref: u,
              tabIndex: -1,
              children: [
                Pr[e - 1].label,
                ' ',
                g.jsx('span', { 'aria-hidden': 'true', children: '—' }),
              ],
            }),
            g.jsx('p', { children: ef[e - 1] }),
          ],
        }),
        g.jsxs(
          'div',
          {
            className: 'request-fields',
            children: [
              e === 1 &&
                g.jsxs(g.Fragment, {
                  children: [
                    g.jsx(De, {
                      name: 'customerName',
                      label: 'نام و نام خانوادگی سفارش دهنده',
                      icon: 'user',
                      required: !0,
                      autoComplete: 'name',
                      placeholder: 'مثال : علی رضایی',
                      rules: {
                        validate: (d) =>
                          d.trim().length > 0 ||
                          'نام و نام خانوادگی را وارد کنید.',
                      },
                    }),
                    g.jsx(_t, {
                      name: 'relationship',
                      label: 'نسبت با متوفی',
                      icon: 'people',
                      options: ['پدر', 'مادر', 'برادر', 'خواهر'],
                    }),
                    g.jsx(De, {
                      name: 'mobile',
                      label: 'تلفن همراه سفارش دهنده',
                      icon: 'phone',
                      type: 'tel',
                      required: !0,
                      autoComplete: 'tel',
                      placeholder: 'مثال : ۰۹۳۵۷۲۴۴۶۷۶',
                      rules: {
                        validate: (d) =>
                          Co(d) || 'شماره همراه ۱۱ رقمی با ۰۹ شروع شود.',
                      },
                    }),
                    g.jsx(De, {
                      name: 'coordinatorPhone',
                      label: 'تلفن هماهنگ کننده (در صورت تفاوت)',
                      icon: 'phone',
                      type: 'tel',
                      placeholder: 'مثال : ۰۹۳۵۷۲۴۴۶۷۶',
                      rules: {
                        validate: (d) =>
                          !d.trim() ||
                          Co(d) ||
                          'شماره همراه ۱۱ رقمی با ۰۹ شروع شود.',
                      },
                    }),
                    g.jsx(De, {
                      name: 'email',
                      label: 'ایمیل (اختیاری)',
                      icon: 'email',
                      type: 'email',
                      autoComplete: 'email',
                      placeholder: 'مثال : atashyamirhossein@gmail.com',
                      rules: {
                        validate: (d) =>
                          !d.trim() ||
                          /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(d.trim()) ||
                          'ایمیل را به شکل صحیح وارد کنید.',
                      },
                    }),
                    g.jsx(_t, {
                      name: 'contactMethod',
                      label: 'روش ارتباط ترجیحی',
                      icon: 'contact',
                      options: ['تلگرام', 'اینستاگرام', 'ایتا', 'روبیکا'],
                    }),
                  ],
                }),
              e === 2 &&
                g.jsxs(g.Fragment, {
                  children: [
                    g.jsx(De, {
                      name: 'deceasedName',
                      label: 'نام و نام خانوادگی متوفی',
                      icon: 'user',
                      placeholder: 'نام و نام خانوادگی',
                      required: !0,
                      fullWidth: !0,
                      rules: {
                        validate: (d) =>
                          !!d.trim() ||
                          'نام و نام خانوادگی متوفی را وارد کنید.',
                      },
                    }),
                    g.jsx(De, {
                      name: 'spouseName',
                      label: 'نام و نام خانوادگی همسر متوفی',
                      icon: 'user',
                      placeholder: 'نام و نام خانوادگی',
                    }),
                    g.jsx(_t, {
                      name: 'spouseStatus',
                      label: 'وضعیت حیات همسر',
                      icon: 'people',
                      options: Qo,
                      required: !1,
                    }),
                    g.jsx(De, {
                      name: 'parentsNames',
                      label: 'نام و نام خانوادگی پدر و مادر متوفی',
                      icon: 'people',
                      placeholder: 'نام و نام خانوادگی پدر و مادر',
                    }),
                    g.jsx(_t, {
                      name: 'parentsStatus',
                      label: 'وضعیت حیات پدر و مادر',
                      icon: 'people',
                      options: Qo,
                      required: !1,
                    }),
                    g.jsx(De, {
                      name: 'children',
                      label: 'فرزندان (اسامی به ترتیب سن)',
                      icon: 'people',
                      placeholder: 'نام فرزندان',
                      fullWidth: !0,
                    }),
                    g.jsx(De, {
                      name: 'inLaws',
                      label: 'عروس‌ها و دامادها به ترتیب',
                      icon: 'people',
                      placeholder: 'نام عروس‌ها و دامادها',
                      fullWidth: !0,
                    }),
                    g.jsx(De, {
                      name: 'grandchildren',
                      label: 'نوه‌ها (اسامی به ترتیب سن)',
                      icon: 'people',
                      placeholder: 'نام نوه‌ها',
                      fullWidth: !0,
                    }),
                  ],
                }),
              e === 3 &&
                g.jsxs(g.Fragment, {
                  children: [
                    g.jsx(_t, {
                      name: 'ceremonyType',
                      label: 'نوع مراسم',
                      icon: 'contact',
                      options: Ju,
                    }),
                    g.jsx(De, {
                      name: 'causeOfDeath',
                      label: 'علت فوت',
                      icon: 'contact',
                      placeholder: 'علت فوت',
                    }),
                    g.jsx(De, {
                      name: 'birthDate',
                      label: 'تاریخ تولد',
                      icon: 'contact',
                      placeholder: 'سال/ماه/روز',
                    }),
                    g.jsx(De, {
                      name: 'deathDate',
                      label: 'تاریخ فوت',
                      icon: 'contact',
                      placeholder: 'سال/ماه/روز',
                    }),
                    g.jsx(De, {
                      name: 'burialPlace',
                      label: 'محل دفن',
                      icon: 'contact',
                      placeholder: 'محل دفن',
                    }),
                    g.jsx(_t, {
                      name: 'deathLocation',
                      label: 'مکان فوت',
                      icon: 'contact',
                      options: ['بیمارستان', 'منزل', nr],
                      required: !1,
                    }),
                    c === nr &&
                      g.jsx(De, {
                        name: 'otherDeathLocation',
                        label: 'مکان دیگر',
                        icon: 'contact',
                        placeholder: 'مکان فوت',
                        fullWidth: !0,
                      }),
                    g.jsx(De, {
                      name: 'acknowledgements',
                      label:
                        'فامیل‌های وابسته، مهمانان از شهرهای دیگر و تشکر ویژه از افراد و سازمان‌ها',
                      icon: 'people',
                      placeholder: 'نام‌ها و توضیحات',
                      fullWidth: !0,
                    }),
                  ],
                }),
              e === 4 &&
                g.jsx(Er, {
                  name: 'biography',
                  control: i,
                  render: ({ field: d }) =>
                    g.jsxs('label', {
                      className: 'request-field--wide',
                      htmlFor: 'request-biography',
                      children: [
                        'شرح حال زندگی متوفی (اختیاری)',
                        g.jsx('span', {
                          className:
                            'request-control request-control--multiline',
                          children: g.jsx('textarea', {
                            ...d,
                            id: 'request-biography',
                            rows: 4,
                            placeholder: 'در صورت تمایل، شرح حال را بنویسید.',
                            onChange: (v) => {
                              (d.onChange(v.currentTarget.value), s(''), r());
                            },
                          }),
                        }),
                      ],
                    }),
                }),
            ],
          },
          e,
        ),
        g.jsxs('div', {
          className: 'request-form__bottom',
          children: [
            g.jsxs('div', {
              className: 'request-privacy',
              children: [
                g.jsxs('h3', {
                  children: [
                    g.jsx(Ai, { name: 'lock' }),
                    'اطلاعات شما محرمانه است',
                  ],
                }),
                g.jsx('p', {
                  children:
                    'اطلاعات وارد شده صرفا جهت هماهنگی مراسم استفاده می شود و با بالاترین سطح امنیت و احترام نگهداری خواهد شد .',
                }),
              ],
            }),
            g.jsxs('div', {
              className: 'request-form__actions',
              children: [
                g.jsx('button', {
                  type: 'submit',
                  children:
                    e === 4
                      ? 'تأیید و پایان'
                      : g.jsxs(g.Fragment, {
                          children: [
                            'ادامه و ورود به مرحله بعد ',
                            g.jsx('span', {
                              'aria-hidden': 'true',
                              children: '←',
                            }),
                          ],
                        }),
                }),
                n
                  ? g.jsx('button', {
                      type: 'button',
                      onClick: () => {
                        (s(''), n());
                      },
                      children: 'بازگشت به مرحله قبل',
                    })
                  : g.jsx('button', {
                      type: 'button',
                      onClick: () =>
                        s(
                          'ذخیره موقت در این پیش‌نمایش فعال نیست؛ اطلاعاتی ذخیره نشده است.',
                        ),
                      children: 'ذخیره موقت اطلاعات',
                    }),
              ],
            }),
            o &&
              g.jsx('p', {
                className: 'request-notice',
                role: 'status',
                children: o,
              }),
          ],
        }),
      ],
    })
  );
}
function nf() {
  return g.jsxs('aside', {
    className: 'request-sidebar request-panel',
    dir: 'rtl',
    'aria-labelledby': 'request-help',
    children: [
      g.jsx('h2', { id: 'request-help', children: 'نیاز به راهنمایی دارید ؟' }),
      g.jsx('p', {
        children:
          'تیم پشتیبانی آنلاین ترحیم آماده است تا در تمام مراحل ثبت درخواست ، راهنمایی و همراه شما باشد',
      }),
      g.jsxs('a', {
        className: 'request-support',
        href: 'tel:02188665157',
        children: [
          g.jsx('img', { src: './assets/request/support-phone.svg', alt: '' }),
          g.jsxs('span', {
            children: [
              g.jsx('bdi', { dir: 'ltr', children: '۰۲۱ - ۸۸۶۶۵۱۵۷' }),
              g.jsx('small', { children: 'همه روزه از ۸ صبح تا ۱۰ شب' }),
            ],
          }),
        ],
      }),
      g.jsxs('div', {
        className: 'request-support',
        children: [
          g.jsx('img', { src: './assets/request/whatsapp.svg', alt: '' }),
          g.jsxs('span', {
            children: [
              'واتساپ',
              g.jsx('small', { children: 'پاسخگویی سریع در واتساپ' }),
            ],
          }),
        ],
      }),
      g.jsxs('div', {
        className: 'request-support request-duration',
        children: [
          g.jsx('img', { src: './assets/live/clock.svg', alt: '' }),
          g.jsxs('div', {
            children: [
              g.jsx('span', { children: 'زمان تقریبی تکمیل فرم' }),
              g.jsx('strong', { children: '۵ تا ۷ دقیقه' }),
            ],
          }),
        ],
      }),
      g.jsxs('div', {
        className: 'request-benefits',
        children: [
          g.jsx('h3', { children: 'با ثبت درخواست در آنلاین ترحیم' }),
          g.jsxs('ul', {
            children: [
              g.jsx('li', {
                children: 'اطلاعات شما با امنیت کامل نگهداری می شود',
              }),
              g.jsx('li', {
                children: 'هماهنگی کامل توسط تیم پشتیبانی انجام می شود',
              }),
              g.jsx('li', {
                children: 'امکان تکمیل فرم در چند مرحله و ذخیره موقت',
              }),
              g.jsx('li', {
                children: 'مشاوره رایگان برای انتخاب بهترین خدمات',
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
const rf = { 1: 2, 2: 3, 3: 4 },
  of = { 2: 1, 3: 2, 4: 3 };
function sf() {
  const [e, t] = f.useState(1),
    [n, r] = f.useState(!1),
    o = ma({ defaultValues: va, mode: 'onTouched' }),
    s = Cr({ control: o.control }),
    i = n ? { filled: 1, total: 1 } : ga(s, e);
  return g.jsxs(pa, {
    ...o,
    children: [
      g.jsx(xa, { progress: i, currentStep: e }),
      g.jsxs('section', {
        className: 'request-content request-container',
        'aria-label': 'فرم درخواست و راهنمای ثبت',
        children: [
          g.jsx(tf, {
            step: e,
            onContinue: () => {
              e === 4 ? r(!0) : t(rf[e]);
            },
            onBack:
              e === 1
                ? void 0
                : () => {
                    (r(!1), t(of[e]));
                  },
            onEdit: () => r(!1),
          }),
          g.jsx(nf, {}),
        ],
      }),
    ],
  });
}
$i('request');
function Pi(e) {
  if (e === 'request') {
    window.scrollTo({ top: 0 });
    return;
  }
  if (qi(e)) {
    Jo(e);
    return;
  }
  window.dispatchEvent(
    new CustomEvent('tarhim:navigate', { detail: { target: e } }),
  );
}
function af(e) {
  if (e === 'ceremonies') {
    Pi('live');
    return;
  }
  ['services', 'archive', 'plans'].includes(e) && Jo('home', e);
}
function cf() {
  return g.jsxs('main', {
    className: 'request-page',
    children: [
      g.jsx(Wi, { onNavigate: Pi, currentTarget: 'request' }),
      g.jsx(sf, {}),
      g.jsx(Ui, {
        onQuickLink: af,
        onService: (e) =>
          window.dispatchEvent(
            new CustomEvent('tarhim:service-details', {
              detail: { serviceId: e },
            }),
          ),
        onSocial: (e) =>
          window.dispatchEvent(
            new CustomEvent('tarhim:social', { detail: { platform: e } }),
          ),
      }),
    ],
  });
}
Bi.createRoot(document.getElementById('root')).render(
  g.jsx(f.StrictMode, { children: g.jsx(cf, {}) }),
);
