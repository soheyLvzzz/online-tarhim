import { r as d, j as o } from './routes.js';
function b(a) {
  const r = d.useRef(null),
    [n, l] = d.useState(0),
    [s, g] = d.useState(!1),
    u = () => {
      const t = r.current;
      if (!t || !window.matchMedia('(max-width: 767px)').matches) return;
      const e = t.getBoundingClientRect().right;
      let i = 0,
        c = 1 / 0;
      (Array.from(t.children).forEach((m, w) => {
        const f = Math.abs(m.getBoundingClientRect().right - e);
        f < c && ((c = f), (i = w));
      }),
        l(i));
    };
  d.useEffect(() => {
    const t = window.matchMedia('(max-width: 767px)'),
      e = () => {
        (g(t.matches), u());
      };
    (e(), t.addEventListener('change', e));
    const i = new ResizeObserver(e);
    return (
      r.current && i.observe(r.current),
      () => {
        (t.removeEventListener('change', e), i.disconnect());
      }
    );
  }, []);
  const h = (t) => {
    const e = r.current;
    if (!e || !window.matchMedia('(max-width: 767px)').matches) return;
    const i = Math.max(0, Math.min(a - 1, t)),
      c = e.children[i];
    c &&
      e.scrollTo({
        left:
          e.scrollLeft +
          c.getBoundingClientRect().right -
          e.getBoundingClientRect().right,
        behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches
          ? 'instant'
          : 'smooth',
      });
  };
  return {
    trackRef: r,
    index: n,
    mobile: s,
    sync: u,
    go: h,
    onKeyDown: (t) => {
      if (!s || t.target !== t.currentTarget) return;
      const e = { ArrowLeft: n + 1, ArrowRight: n - 1, Home: 0, End: a - 1 }[
        t.key
      ];
      e !== void 0 && (t.preventDefault(), h(e));
    },
  };
}
function k({ id: a, label: r, index: n, count: l, onGo: s }) {
  return o.jsxs('div', {
    className: 'mobile-carousel-controls',
    role: 'group',
    'aria-label': `کنترل اسلایدهای ${r}`,
    children: [
      o.jsx('button', {
        type: 'button',
        disabled: n === 0,
        onClick: () => s(n - 1),
        'aria-controls': a,
        'aria-label': `اسلاید قبلی ${r}`,
        children: o.jsx('svg', {
          viewBox: '0 0 24 24',
          width: '24',
          height: '24',
          fill: 'none',
          'aria-hidden': 'true',
          children: o.jsx('path', {
            d: 'm9 5 7 7-7 7',
            stroke: 'currentColor',
            strokeWidth: '1.5',
            strokeLinecap: 'round',
            strokeLinejoin: 'round',
          }),
        }),
      }),
      o.jsxs('span', {
        'aria-live': 'polite',
        'aria-atomic': 'true',
        children: [
          (n + 1).toLocaleString('fa-IR'),
          ' از ',
          l.toLocaleString('fa-IR'),
        ],
      }),
      o.jsx('button', {
        type: 'button',
        disabled: n === l - 1,
        onClick: () => s(n + 1),
        'aria-controls': a,
        'aria-label': `اسلاید بعدی ${r}`,
        children: o.jsx('svg', {
          viewBox: '0 0 24 24',
          width: '24',
          height: '24',
          fill: 'none',
          'aria-hidden': 'true',
          children: o.jsx('path', {
            d: 'm15 5-7 7 7 7',
            stroke: 'currentColor',
            strokeWidth: '1.5',
            strokeLinecap: 'round',
            strokeLinejoin: 'round',
          }),
        }),
      }),
    ],
  });
}
export { k as M, b as u };
