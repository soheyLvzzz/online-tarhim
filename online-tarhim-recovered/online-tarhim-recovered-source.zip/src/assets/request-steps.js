const Ar = () => q.useContext(Rr),
  pa = ({
    children: e,
    watch: t,
    getValues: n,
    getErrors: r,
    getFieldState: o,
    setError: s,
    clearErrors: i,
    setValue: a,
    setValues: c,
    trigger: u,
    formState: h,
    resetField: d,
    reset: v,
    resetDefaultValues: S,
    handleSubmit: C,
    unregister: b,
    control: y,
    register: E,
    setFocus: A,
    subscribe: m,
  }) => {
    const w = q.useMemo(
      () => ({
        watch: t,
        getValues: n,
        getErrors: r,
        getFieldState: o,
        setError: s,
        clearErrors: i,
        setValue: a,
        setValues: c,
        trigger: u,
        formState: h,
        resetField: d,
        reset: v,
        resetDefaultValues: S,
        handleSubmit: C,
        unregister: b,
        control: y,
        register: E,
        setFocus: A,
        subscribe: m,
      }),
      [i, y, h, r, o, n, C, E, v, S, d, s, A, a, c, m, u, b, t],
    );
    return q.createElement(
      Rr.Provider,
      { value: w },
      q.createElement(xr.Provider, { value: w.control }, e),
    );
  },
  va = {
    customerName: '',
    mobile: '',
    coordinatorPhone: '',
    email: '',
    relationship: '',
    contactMethod: '',
    deceasedName: '',
    spouseName: '',
    spouseStatus: '',
    parentsNames: '',
    parentsStatus: '',
    children: '',
    inLaws: '',
    grandchildren: '',
    ceremonyType: '',
    causeOfDeath: '',
    birthDate: '',
    deathDate: '',
    burialPlace: '',
    deathLocation: '',
    otherDeathLocation: '',
    acknowledgements: '',
    biography: '',
  },
  Pr = [
    {
      label: 'اطلاعات سفارش دهنده',
      fields: [
        'customerName',
        'mobile',
        'coordinatorPhone',
        'email',
        'relationship',
        'contactMethod',
      ],
    },
    {
      label: 'اطلاعات متوفی',
      fields: [
        'deceasedName',
        'spouseName',
        'spouseStatus',
        'parentsNames',
        'parentsStatus',
        'children',
        'inLaws',
        'grandchildren',
      ],
    },
    {
      label: 'جزئیات مراسم',
      fields: [
        'ceremonyType',
        'causeOfDeath',
        'birthDate',
        'deathDate',
        'burialPlace',
        'deathLocation',
        'acknowledgements',
      ],
    },
    { label: 'توضیحات و تایید', fields: ['biography'] },
  ],
  nr = 'غیره';
function ga(e, t = 1) {
  const n = Pr[t - 1].fields,
    r = t === 3 && e.deathLocation === nr ? [...n, 'otherDeathLocation'] : n;
  return {
    filled: r.filter((o) => (e[o] ?? '').trim().length > 0).length,
    total: r.length,
  };
}
function ya(e) {
  return e
    .replace(/[۰-۹]/g, (t) => String(t.charCodeAt(0) - 1776))
    .replace(/[٠-٩]/g, (t) => String(t.charCodeAt(0) - 1632));
}
function Co(e) {
  return /^09\d{9}$/.test(ya(e.trim()));
}
function xa({ progress: e = { filled: 0, total: 6 }, currentStep: t = 1 }) {
  const n = e.total > 0 ? Math.min(1, Math.max(0, e.filled / e.total)) : 0;
  return g.jsxs('section', {
    className: 'request-hero',
    'aria-labelledby': 'request-title',
    children: [
      g.jsx('div', {
        className: 'request-hero__background',
        'aria-hidden': 'true',
        children: g.jsx('img', {
          src: './assets/memorial/hero-background.png',
          alt: '',
        }),
      }),
      g.jsxs('div', {
        className: 'request-container',
        children: [
          g.jsxs('div', {
            className: 'request-hero__eyebrow',
            children: [
              g.jsx('span', {}),
              'ثبت درخواست برگزاری مراسم',
              g.jsx('span', {}),
            ],
          }),
          g.jsx('h1', {
            id: 'request-title',
            children: 'درخواست اجرای مراسم آنلاین ترحیم',
          }),
          g.jsxs('p', {
            children: [
              'با تکمیل این فرم در چند مرحله ساده درخواست خود را ثبت کنید',
              g.jsx('br', {}),
              'کارشناسان ما در اسرع وقت با شما تماس خواهند گرفت و هماهنگی های لازم را انجام می دهند.',
            ],
          }),
          g.jsx('div', {
            className: 'request-progress-status',
            role: 'progressbar',
            'aria-label': `میزان تکمیل فیلدهای مرحلهٔ ${t.toLocaleString('fa-IR')}`,
            'aria-valuemin': 0,
            'aria-valuemax': Math.max(1, e.total),
            'aria-valuenow': e.filled,
          }),
          g.jsx('ol', {
            className: 'request-steps',
            'aria-label': 'مراحل درخواست',
            children: Pr.map(({ label: r }, o) => {
              const s = o + 1,
                i = s < t ? 100 : s === t ? n * 100 : 0;
              return g.jsxs(
                'li',
                {
                  'aria-current': s === t ? 'step' : void 0,
                  'data-completed': s < t ? !0 : void 0,
                  children: [
                    s < 4 &&
                      g.jsx('span', {
                        className: 'request-steps__connector',
                        'aria-hidden': 'true',
                        children:
                          s <= t &&
                          g.jsx('span', {
                            className: 'request-steps__fill',
                            style: { width: `${i}%` },
                          }),
                      }),
                    g.jsx('span', {
                      className: 'request-steps__number',
                      children: s.toLocaleString('fa-IR'),
                    }),
                    g.jsx('span', { children: r }),
                  ],
                },
                r,
              );
            }),
          }),
        ],
      }),
    ],
  });
}
