import {
  j as e,
  i as o,
  c as v,
  r as m,
  H as h,
  F as x,
  a as j,
  n as c,
} from './routes.js';
import { u, M as g } from './MobileCarouselControls.js';
/* empty css               */ function _({
  onEnter: s,
  onMemorial: l,
  onLoadMore: a,
}) {
  const i = u(3);
  return e.jsxs('section', {
    className: 'live-hero',
    dir: 'rtl',
    'aria-labelledby': 'live-title',
    'data-node-id': '55:410',
    children: [
      e.jsxs('div', {
        className: 'live-hero__backdrop',
        'aria-hidden': 'true',
        children: [
          e.jsx('div', {
            className: 'live-hero__crop',
            children: e.jsx('img', {
              src: './assets/live/hero-background.png',
              alt: '',
            }),
          }),
          e.jsx('div', { className: 'live-hero__shade' }),
        ],
      }),
      e.jsxs('div', {
        className: 'live-container',
        children: [
          e.jsxs('div', {
            className: 'live-hero__heading',
            'data-node-id': '55:291',
            children: [
              e.jsxs('div', {
                className: 'live-hero__eyebrow',
                children: [
                  e.jsx('img', {
                    src: './assets/live/eyebrow-line.svg',
                    alt: '',
                  }),
                  e.jsx('span', { children: 'همراهی در سوگ عزیزان' }),
                  e.jsx('img', {
                    src: './assets/live/eyebrow-line.svg',
                    alt: '',
                  }),
                ],
              }),
              e.jsx('h1', {
                id: 'live-title',
                children: 'مراسم های درحال برگزاری',
              }),
              e.jsxs('p', {
                children: [
                  'در کنار خانواده ها و عزیزانی که یادشان همیشه زنده است .',
                  e.jsx('br', {}),
                  'به احترام و همدلی حضور داریم .',
                ],
              }),
            ],
          }),
          e.jsx('div', {
            className: 'live-hero__cards mobile-carousel-track',
            id: 'live-ceremonies-carousel',
            ref: i.trackRef,
            onScroll: i.sync,
            onKeyDown: i.onKeyDown,
            tabIndex: i.mobile ? 0 : void 0,
            role: i.mobile ? 'group' : void 0,
            'aria-label': i.mobile ? 'مراسم‌های در حال اجرا' : void 0,
            children: ['ceremony-1', 'ceremony-2', 'ceremony-3'].map((r, t) =>
              e.jsxs(
                'article',
                {
                  className: 'live-card',
                  'aria-labelledby': `live-${r}`,
                  'data-node-id': ['55:336', '55:335', '55:370'][t],
                  children: [
                    e.jsx('img', {
                      className: 'live-card__image',
                      src: './assets/live/ceremony-candles.png',
                      alt: 'شمع‌های روشن مراسم یادبود',
                    }),
                    e.jsxs('div', {
                      className: 'live-card__badges',
                      children: [
                        e.jsx('span', {
                          className: 'live-card__badge',
                          children: 'مراسم یادبود',
                        }),
                        e.jsx('span', {
                          className: 'live-card__status',
                          children: 'درحال پخش',
                        }),
                      ],
                    }),
                    e.jsx('h2', {
                      id: `live-${r}`,
                      children: 'مرحوم محمد رضایی',
                    }),
                    e.jsx('p', {
                      className: 'live-card__description',
                      children: 'مراسم بزرگداشت و گرامیداشت یاد عزیزان',
                    }),
                    e.jsxs('div', {
                      className: 'live-card__schedule',
                      children: [
                        e.jsxs('span', {
                          className: 'live-card__date',
                          children: [
                            e.jsx('img', {
                              src: './assets/live/calendar.svg',
                              alt: '',
                            }),
                            e.jsx('span', { children: 'پنجشنبه ، آبان 1405' }),
                          ],
                        }),
                        e.jsx('span', {
                          className: 'live-card__date-divider',
                          'aria-hidden': 'true',
                          children: e.jsx('img', {
                            src: './assets/live/date-divider.svg',
                            alt: '',
                          }),
                        }),
                        e.jsxs('span', {
                          className: 'live-card__time',
                          children: [
                            e.jsx('img', {
                              src: './assets/live/clock.svg',
                              alt: '',
                            }),
                            e.jsxs('span', {
                              children: [
                                e.jsx('bdi', { children: '8:30' }),
                                ' الی ',
                                e.jsx('bdi', { children: '10:00' }),
                              ],
                            }),
                          ],
                        }),
                      ],
                    }),
                    e.jsx('div', {
                      className: 'live-card__divider',
                      'aria-hidden': 'true',
                      children: e.jsx('img', {
                        src: './assets/live/card-divider.svg',
                        alt: '',
                      }),
                    }),
                    e.jsxs('div', {
                      className: 'live-card__actions',
                      children: [
                        e.jsxs('button', {
                          className: 'live-card__enter',
                          type: 'button',
                          onClick: () => s(r),
                          children: [
                            e.jsx('span', { children: 'ورود به مراسم' }),
                            e.jsx('img', {
                              src: './assets/live/enter-arrow.svg',
                              alt: '',
                            }),
                          ],
                        }),
                        e.jsxs('button', {
                          className: 'live-card__memorial',
                          type: 'button',
                          onClick: () => l(r),
                          children: [
                            e.jsx('img', {
                              src: './assets/live/book.svg',
                              alt: '',
                            }),
                            e.jsx('span', { children: 'صفحه یادبود متوفی' }),
                          ],
                        }),
                      ],
                    }),
                  ],
                },
                r,
              ),
            ),
          }),
          e.jsx(g, {
            id: 'live-ceremonies-carousel',
            label: 'مراسم‌های در حال اجرا',
            index: i.index,
            count: 3,
            onGo: i.go,
          }),
          e.jsxs('button', {
            className: 'live-hero__load',
            type: 'button',
            onClick: a,
            children: [
              e.jsx('span', { children: 'بارگذاری بیشتر' }),
              e.jsx('span', {
                className: 'live-hero__load-icon',
                'aria-hidden': 'true',
                children: e.jsx('img', {
                  src: './assets/live/load-arrow.svg',
                  alt: '',
                }),
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
const p = [
  {
    id: 'find',
    icon: './assets/live/guide/search.svg',
    title: 'مراسم را پیدا کنید',
    description:
      'نام عزیزتان یا عنوان مراسم را در فهرست مراسم های درحال اجرا جست و جو کنید .',
  },
  {
    id: 'open',
    icon: './assets/live/guide/document.svg',
    title: 'وارد صفحه مراسم شوید',
    description:
      'روی کارت مراسم بزنید و جزئیات و گزینه ورود به برنامه را مشاهده کنید .',
  },
  {
    id: 'join',
    icon: './assets/live/guide/people.svg',
    title: 'به جمع همراهان بپیوندید',
    description:
      'مراحل نمایش داده شده را دنبال کنید و وارد فضای برگزاری مراسم شوید .',
  },
];
function N({ posterSrc: s, onPlay: l }) {
  return e.jsx('section', {
    className: 'live-guide',
    dir: 'rtl',
    'aria-labelledby': 'live-guide-title',
    'data-node-id': '72:522',
    children: e.jsxs('div', {
      className: 'live-container live-guide__layout',
      children: [
        e.jsxs('div', {
          className: 'live-guide__copy',
          children: [
            e.jsxs('div', {
              className: 'live-guide__eyebrow',
              children: [
                e.jsx('span', { children: 'راهنمای ورود به برنامه' }),
                e.jsx('img', {
                  src: './assets/live/eyebrow-line.svg',
                  alt: '',
                }),
              ],
            }),
            e.jsx('h2', {
              id: 'live-guide-title',
              children: 'چطور وارد مراسم آنلاین شویم؟',
            }),
            e.jsx('p', {
              className: 'live-guide__intro',
              children:
                'برای همراهی با خانواده و عزیزان ، کافی است چند مرحله ساده را دنبال کنید ، و در هرکجای دنیا که هستید در مراسم حضور داشته باشید . در این ویدیو مراحل ورود به برنامه را به صورت کامل مشاهده می کنید .',
            }),
            e.jsx('div', {
              className: 'live-guide__steps',
              children: p.map((a) =>
                e.jsxs(
                  'div',
                  {
                    className: 'live-guide__step',
                    children: [
                      e.jsx('span', {
                        className: 'live-guide__step-icon',
                        'aria-hidden': 'true',
                        children: e.jsx('span', {
                          children: e.jsx('img', { src: a.icon, alt: '' }),
                        }),
                      }),
                      e.jsxs('div', {
                        className: 'live-guide__step-copy',
                        children: [
                          e.jsx('h3', {
                            className: 'live-guide__step-title',
                            tabIndex: 0,
                            children: e.jsx('span', { children: a.title }),
                          }),
                          e.jsx('p', { children: a.description }),
                        ],
                      }),
                    ],
                  },
                  a.id,
                ),
              ),
            }),
          ],
        }),
        e.jsxs('div', {
          className: 'live-guide__video',
          children: [
            e.jsx('img', { className: 'live-guide__poster', src: s, alt: '' }),
            e.jsx('button', {
              className: 'live-guide__play',
              type: 'button',
              onClick: l,
              'aria-label': 'پخش ویدیوی راهنمای ورود به مراسم',
              children: e.jsx('img', {
                src: './assets/live/guide/play.svg',
                alt: '',
              }),
            }),
          ],
        }),
      ],
    }),
  });
}
o('live');
function d(s) {
  if (s === 'live') {
    window.scrollTo({ top: 0 });
    return;
  }
  if (j(s)) {
    c(s);
    return;
  }
  window.dispatchEvent(
    new CustomEvent('tarhim:navigate', { detail: { target: s } }),
  );
}
function b(s) {
  if (s === 'ceremonies') {
    d('live');
    return;
  }
  ['services', 'archive', 'plans'].includes(s) && c('home', s);
}
function n(s, l) {
  window.dispatchEvent(
    new CustomEvent(`tarhim:${s}`, { detail: { ceremonyId: l } }),
  );
}
v.createRoot(document.getElementById('root')).render(
  e.jsx(m.StrictMode, {
    children: e.jsxs('main', {
      className: 'live-page',
      children: [
        e.jsx(h, { onNavigate: d, currentTarget: 'live' }),
        e.jsx(_, {
          onEnter: (s) => n('enter-ceremony', s),
          onMemorial: (s) => n('open-memorial', s),
          onLoadMore: () => n('load-live-ceremonies'),
        }),
        e.jsx(N, {
          posterSrc: './assets/live/guide/video-poster.jpg',
          onPlay: () => n('play-ceremony-guide'),
        }),
        e.jsx(x, {
          onQuickLink: b,
          onService: (s) =>
            window.dispatchEvent(
              new CustomEvent('tarhim:service-details', {
                detail: { serviceId: s },
              }),
            ),
          onSocial: (s) =>
            window.dispatchEvent(
              new CustomEvent('tarhim:social', { detail: { platform: s } }),
            ),
        }),
      ],
    }),
  }),
);
