import {
  r as c,
  j as e,
  i as g,
  c as N,
  H as v,
  F as b,
  a as f,
  n as h,
} from './routes.js';
/* empty css               */ const y = [
    './assets/memorial/post/family-1.png',
    './assets/memorial/post/family-2.png',
    './assets/memorial/post/family-3.png',
  ],
  w = {
    'heading-line': './assets/memorial/post/heading-line.svg',
    clock: './assets/memorial/post/clock.svg',
    online: './assets/memorial/post/online.svg',
    location: './assets/memorial/post/location.svg',
    name: './assets/memorial/post/name.svg',
    relationship: './assets/memorial/post/relationship.svg',
    message: './assets/memorial/post/message.svg',
    'enter-arrow': './assets/memorial/post/enter-arrow.svg',
    'map-arrow': './assets/memorial/post/map-arrow.svg',
    'submit-arrow': './assets/memorial/post/submit-arrow.svg',
    'more-arrow': './assets/memorial/post/more-arrow.svg',
  },
  k = ['first', 'second', 'third', 'fourth'];
function i({ name: s }) {
  return e.jsx('img', { src: w[s], alt: '' });
}
function r({ id: s, title: o, className: l = '', children: t }) {
  return e.jsxs('section', {
    className: `memorial-post__panel ${l}`,
    'aria-labelledby': s,
    children: [
      e.jsxs('h2', {
        id: s,
        children: [o, e.jsx(i, { name: 'heading-line' })],
      }),
      t,
    ],
  });
}
function x({ name: s, label: o, icon: l, multiline: t = !1 }) {
  return e.jsxs('label', {
    className: `memorial-post__field${t ? ' memorial-post__field--message' : ''}`,
    children: [
      e.jsx('span', {
        className: 'memorial-post__field-icon',
        children: e.jsx(i, { name: l }),
      }),
      t
        ? e.jsx('textarea', {
            name: s,
            required: !0,
            maxLength: 2e3,
            'aria-label': o,
            placeholder: ' ',
          })
        : e.jsx('input', {
            name: s,
            required: !0,
            maxLength: 120,
            'aria-label': o,
            autoComplete: s === 'name' ? 'name' : void 0,
            placeholder: ' ',
          }),
      e.jsxs('span', {
        className: 'memorial-post__placeholder',
        'aria-hidden': 'true',
        children: [o, ' ', e.jsx('b', { children: '*' })],
      }),
    ],
  });
}
function C() {
  const [s, o] = c.useState(!1),
    [l, t] = c.useState(''),
    [n, d] = c.useState();
  function u(a) {
    a.preventDefault();
    const m = new FormData(a.currentTarget);
    if (
      ['name', 'relationship', 'message'].some(
        (p) => !String(m.get(p) ?? '').trim(),
      )
    ) {
      t('لطفاً همهٔ فیلدها را تکمیل کنید.');
      return;
    }
    t('پیام در نسخهٔ آزمایشی بررسی شد. اطلاعاتی ارسال نشده است.');
  }
  return e.jsxs('main', {
    children: [
      e.jsxs('section', {
        className: 'memorial-post__hero',
        'aria-labelledby': 'memorial-post-title',
        children: [
          e.jsx('div', {
            className: 'memorial-post__backdrop',
            'aria-hidden': 'true',
            children: e.jsx('img', {
              src: './assets/memorial/post/backdrop.jpg',
              alt: '',
            }),
          }),
          e.jsxs('div', {
            className: 'memorial-post__container',
            children: [
              e.jsx('img', {
                className: 'memorial-post__portrait',
                src: './assets/memorial/post/portrait.png',
                alt: 'تصویر مرحوم حاج علی اکبر رحیمی',
                width: 523,
                height: 420,
              }),
              e.jsx('h1', {
                id: 'memorial-post-title',
                children: 'به یاد مرحوم حاج علی اکبر رحیمی',
              }),
              e.jsx('p', {
                className: 'memorial-post__years',
                children: e.jsx('bdi', { dir: 'ltr', children: '۱۳۴۸ - ۱۴۰۴' }),
              }),
              e.jsx('p', { children: 'روحش شاد و یادش گرامی باد' }),
            ],
          }),
        ],
      }),
      e.jsxs('div', {
        className: 'memorial-post__container memorial-post__content',
        children: [
          e.jsxs('div', {
            className: 'memorial-post__top',
            children: [
              e.jsxs('div', {
                className: 'memorial-post__story',
                children: [
                  e.jsx(r, {
                    id: 'memorial-story',
                    title: 'زندگینامه و خاطرات',
                    className: 'memorial-post__biography',
                    children: e.jsx('p', {
                      children:
                        'لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد کتابهای زیادی در شصت و سه درصد گذشته حال و آینده شناخت فراوان جامعه و متخصصان را می طلبد تا با نرم افزارها شناخت بیشتری را برای طراحان رایانه ای علی الخصوص طراحان خلاقی و فرهنگ پیشرو در زبان فارسی ایجاد کرد در این صورت می توان امید داشت که تمام و دشواری موجود در ارائه راهکارها',
                    }),
                  }),
                  e.jsx(r, {
                    id: 'memorial-gallery',
                    title: 'تصاویر و خاطرات',
                    children: e.jsx('div', {
                      className: 'memorial-post__gallery',
                      children: y.map((a, m) =>
                        e.jsx(
                          'img',
                          {
                            src: a,
                            alt: `عکس خانوادگی ${m + 1}`,
                            width: 269,
                            height: 269,
                            loading: 'lazy',
                          },
                          a,
                        ),
                      ),
                    }),
                  }),
                ],
              }),
              e.jsxs('aside', {
                className: 'memorial-post__sidebar',
                children: [
                  e.jsxs(r, {
                    id: 'memorial-ceremony',
                    title: 'اطلاعات مراسم',
                    className: 'memorial-post__ceremony',
                    children: [
                      e.jsxs('dl', {
                        className: 'memorial-post__facts',
                        children: [
                          e.jsxs('div', {
                            children: [
                              e.jsxs('dt', {
                                children: [
                                  e.jsx(i, { name: 'clock' }),
                                  'تاریخ و زمان :',
                                ],
                              }),
                              e.jsxs('dd', {
                                children: [
                                  'جمعه ۱۶ آبان ساعت ',
                                  e.jsx('bdi', {
                                    dir: 'ltr',
                                    children: '۱۵:۰۰',
                                  }),
                                ],
                              }),
                            ],
                          }),
                          e.jsxs('div', {
                            children: [
                              e.jsxs('dt', {
                                children: [
                                  e.jsx(i, { name: 'online' }),
                                  'نحوه برگزاری :',
                                ],
                              }),
                              e.jsx('dd', { children: 'آنلاین' }),
                            ],
                          }),
                        ],
                      }),
                      e.jsxs('button', {
                        className: 'memorial-post__button',
                        type: 'button',
                        onClick: () =>
                          d({
                            panel: 'ceremony',
                            text: 'پیوند ورود به مراسم هنوز وارد نشده است.',
                          }),
                        children: [
                          'ورود به مراسم ',
                          e.jsx(i, { name: 'enter-arrow' }),
                        ],
                      }),
                      n?.panel === 'ceremony' &&
                        e.jsx('p', {
                          className: 'memorial-post__notice',
                          role: 'status',
                          children: n.text,
                        }),
                    ],
                  }),
                  e.jsxs(r, {
                    id: 'memorial-location',
                    title: 'آدرس مزار',
                    className: 'memorial-post__location',
                    children: [
                      e.jsxs('p', {
                        className: 'memorial-post__address',
                        children: [
                          e.jsx(i, { name: 'location' }),
                          'بهشت زهرا (س)، قطعه ۴۲، ردیف ۱۸، شماره ۱۲',
                        ],
                      }),
                      e.jsxs('div', {
                        className: 'memorial-post__map-buttons',
                        children: [
                          e.jsxs('button', {
                            className: 'memorial-post__button',
                            type: 'button',
                            onClick: () =>
                              d({
                                panel: 'location',
                                text: 'پیوند مسیریابی گوگل هنوز وارد نشده است.',
                              }),
                            children: [
                              'مسیریابی با گوگل ',
                              e.jsx(i, { name: 'enter-arrow' }),
                            ],
                          }),
                          e.jsxs('button', {
                            className:
                              'memorial-post__button memorial-post__button--filled',
                            type: 'button',
                            onClick: () =>
                              d({
                                panel: 'location',
                                text: 'پیوند مسیریابی نشان هنوز وارد نشده است.',
                              }),
                            children: [
                              'مسیریابی با نشان ',
                              e.jsx(i, { name: 'map-arrow' }),
                            ],
                          }),
                        ],
                      }),
                      n?.panel === 'location' &&
                        e.jsx('p', {
                          className: 'memorial-post__notice',
                          role: 'status',
                          children: n.text,
                        }),
                    ],
                  }),
                ],
              }),
            ],
          }),
          e.jsxs('div', {
            className: 'memorial-post__bottom',
            children: [
              e.jsx(r, {
                id: 'memorial-condolence',
                title: 'ارسال پیام تسلیت',
                children: e.jsxs('form', {
                  className: 'memorial-post__form',
                  onSubmit: u,
                  onChange: () => t(''),
                  children: [
                    e.jsx(x, {
                      name: 'name',
                      label: 'نام و نام خانوادگی',
                      icon: 'name',
                    }),
                    e.jsx(x, {
                      name: 'relationship',
                      label: 'نسبت',
                      icon: 'relationship',
                    }),
                    e.jsx(x, {
                      name: 'message',
                      label: 'متن پیام',
                      icon: 'message',
                      multiline: !0,
                    }),
                    e.jsxs('button', {
                      type: 'submit',
                      className:
                        'memorial-post__button memorial-post__button--filled',
                      children: [
                        'ادامه و ورود به مرحله بعد ',
                        e.jsx(i, { name: 'submit-arrow' }),
                      ],
                    }),
                    l &&
                      e.jsx('p', {
                        className: 'memorial-post__notice',
                        role: 'status',
                        children: l,
                      }),
                  ],
                }),
              }),
              e.jsxs(r, {
                id: 'memorial-messages',
                title: 'پیام های ثبت شده',
                className: 'memorial-post__messages',
                children: [
                  e.jsx('ol', {
                    id: 'memorial-message-list',
                    className: 'memorial-post__message-list',
                    children: k.map((a, m) => {
                      const p = m >= 3,
                        _ = e.jsxs('div', {
                          className: 'memorial-post__message',
                          children: [
                            e.jsxs('div', {
                              children: [
                                e.jsx('h3', { children: 'علی مرادی' }),
                                e.jsx('span', { children: '۱۲ آبان ۱۴۰۵' }),
                              ],
                            }),
                            e.jsx('p', {
                              children:
                                'یاد و خاطره ایشان همیشه در قلب ما باقی خواهد ماند . روحشان شاد و یادشان گرامی',
                            }),
                          ],
                        });
                      return p
                        ? e.jsx(
                            'li',
                            {
                              className: 'memorial-post__extra-message',
                              inert: !s,
                              'data-open': s,
                              children: e.jsx('div', {
                                className: 'memorial-post__extra-inner',
                                children: _,
                              }),
                            },
                            a,
                          )
                        : e.jsx('li', { children: _ }, a);
                    }),
                  }),
                  e.jsx('div', {
                    className: `memorial-post__more${s ? ' memorial-post__more--expanded' : ''}`,
                    children: e.jsxs('button', {
                      type: 'button',
                      'aria-expanded': s,
                      'aria-controls': 'memorial-message-list',
                      onClick: () => o((a) => !a),
                      children: [
                        s ? 'مشاهده کمتر' : 'مشاهده بیشتر',
                        ' ',
                        e.jsx(i, { name: 'more-arrow' }),
                      ],
                    }),
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
g('memorialPost');
function E(s) {
  f(s) ? h(s) : j('navigate', { target: s });
}
function S(s) {
  (s === 'ceremonies' && h('live'),
    ['services', 'archive', 'plans'].includes(s) && h('home', s));
}
function j(s, o) {
  window.dispatchEvent(new CustomEvent(`tarhim:${s}`, { detail: o }));
}
N.createRoot(document.getElementById('root')).render(
  e.jsx(c.StrictMode, {
    children: e.jsxs('div', {
      className: 'memorial-post-page',
      children: [
        e.jsx(v, { onNavigate: E, currentTarget: 'memorial' }),
        e.jsx(C, {}),
        e.jsx(b, {
          onQuickLink: S,
          onService: (s) => j('service-details', { serviceId: s }),
          onSocial: (s) => j('social', { platform: s }),
        }),
      ],
    }),
  }),
);
