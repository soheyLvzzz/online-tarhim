import {
  r as c,
  j as e,
  i as g,
  c as j,
  H as p,
  n as d,
  F as v,
  a as b,
} from './routes.js';
import { u as f, M as y } from './MobileCarouselControls.js';
/* empty css               */ function _({
  records: i,
  onView: l,
  onLoadMore: s,
  sortOrder: r,
  onSort: a,
  resetKey: m,
}) {
  const t = f(i.length),
    x = i.map((n) => n.id).join('|');
  return (
    c.useEffect(() => {
      const n = t.trackRef.current;
      n && (n.scrollTo({ left: 0, behavior: 'instant' }), t.sync());
    }, [x, m]),
    e.jsx('section', {
      className: 'memorial-listing',
      dir: 'rtl',
      'aria-labelledby': 'memorial-listing-title',
      children: e.jsxs('div', {
        className: 'memorial-index-container',
        children: [
          e.jsxs('div', {
            className: 'memorial-listing__heading',
            children: [
              e.jsx('h2', {
                id: 'memorial-listing-title',
                children: 'یادبود های ثبت شده',
              }),
              e.jsx('span', {
                className: 'memorial-listing__line',
                'aria-hidden': 'true',
              }),
              e.jsxs('label', {
                className: 'memorial-listing__sort',
                children: [
                  e.jsx('span', { children: 'مرتب سازی :' }),
                  e.jsxs('select', {
                    'aria-label': 'مرتب‌سازی بر اساس تاریخ مراسم',
                    value: r,
                    onChange: (n) =>
                      a(
                        n.currentTarget.value === 'oldest'
                          ? 'oldest'
                          : 'newest',
                      ),
                    children: [
                      e.jsx('option', {
                        value: 'newest',
                        children: 'جدیدترین',
                      }),
                      e.jsx('option', {
                        value: 'oldest',
                        children: 'قدیمی‌ترین',
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
          e.jsxs('div', {
            className: 'memorial-listing__grid mobile-carousel-track',
            id: 'memorial-cards-carousel',
            ref: t.trackRef,
            onScroll: t.sync,
            onKeyDown: t.onKeyDown,
            tabIndex: t.mobile && i.length ? 0 : void 0,
            role: t.mobile ? 'group' : void 0,
            'aria-label': t.mobile ? 'یادبودهای ثبت‌شده' : void 0,
            'aria-live': 'polite',
            children: [
              i.map((n) =>
                e.jsxs(
                  'article',
                  {
                    className: 'memorial-card',
                    'aria-labelledby': `${n.id}-title`,
                    children: [
                      e.jsx('img', {
                        className: 'memorial-card__background',
                        src: './assets/memorial/card-background-figma.png',
                        alt: '',
                      }),
                      e.jsxs('div', {
                        className: 'memorial-card__copy',
                        children: [
                          e.jsx('h3', {
                            id: `${n.id}-title`,
                            children: n.name,
                          }),
                          e.jsx('p', { children: 'یاد و خاطره اش گرامی' }),
                        ],
                      }),
                      e.jsxs('div', {
                        className: 'memorial-card__dates',
                        children: [
                          e.jsxs('p', {
                            children: [
                              e.jsx('img', {
                                src: './assets/live/calendar.svg',
                                alt: '',
                              }),
                              e.jsxs('span', {
                                children: [
                                  'تاریخ درگذشت ',
                                  e.jsx('bdi', {
                                    dir: 'ltr',
                                    children: n.deathDate,
                                  }),
                                ],
                              }),
                            ],
                          }),
                          e.jsxs('p', {
                            children: [
                              e.jsx('img', {
                                src: './assets/live/guide/people.svg',
                                alt: '',
                              }),
                              e.jsxs('span', {
                                children: [
                                  'تاریخ مراسم ',
                                  e.jsx('bdi', {
                                    dir: 'ltr',
                                    children: n.ceremonyDate,
                                  }),
                                ],
                              }),
                            ],
                          }),
                        ],
                      }),
                      e.jsxs('button', {
                        className: 'memorial-card__view',
                        type: 'button',
                        onClick: () => l(n.id),
                        'aria-label': `مشاهده یادبود ${n.name}`,
                        children: [
                          e.jsx('span', { children: 'مشاهده' }),
                          e.jsx('span', {
                            className: 'memorial-card__arrow',
                            'aria-hidden': 'true',
                          }),
                        ],
                      }),
                    ],
                  },
                  n.id,
                ),
              ),
              !i.length &&
                e.jsx('p', {
                  className: 'memorial-listing__empty',
                  children: 'یادبودی با این نام پیدا نشد.',
                }),
            ],
          }),
          i.length > 1 &&
            e.jsx(y, {
              id: 'memorial-cards-carousel',
              label: 'یادبودهای ثبت‌شده',
              index: t.index,
              count: i.length,
              onGo: t.go,
            }),
          !!i.length &&
            e.jsx('button', {
              className: 'memorial-listing__more',
              type: 'button',
              onClick: s,
              children: 'مشاهده بیشتر',
            }),
        ],
      }),
    })
  );
}
const N = Array.from({ length: 6 }, (i, l) => ({
  id: `memorial-${l + 1}`,
  name: 'محمد طاهری',
  deathDate: '1402/09/02',
  ceremonyDate: '1402/09/02',
}));
function u(i) {
  return i
    .normalize('NFKC')
    .replace(/ي/g, 'ی')
    .replace(/ك/g, 'ک')
    .replace(/[\u064b-\u065f\u0670]/g, '')
    .replace(/[\s\u200c]+/g, ' ')
    .trim();
}
function w(i, l) {
  const s = u(l);
  return s ? i.filter((r) => u(r.name).includes(s)) : i;
}
function S(i) {
  const l = i
      .replace(/[۰-۹]/g, (t) => String(t.charCodeAt(0) - 1776))
      .replace(/[٠-٩]/g, (t) => String(t.charCodeAt(0) - 1632)),
    s = /^(\d{4})[/-](\d{1,2})[/-](\d{1,2})$/.exec(l.trim());
  if (!s) return null;
  const [, r, a, m] = s.map(Number);
  return a < 1 || a > 12 || m < 1 || m > 31 ? null : r * 1e4 + a * 100 + m;
}
function k(i, l) {
  const s = l === 'oldest' ? 1 : -1;
  return i
    .map((r, a) => ({ record: r, index: a, date: S(r.ceremonyDate) }))
    .sort((r, a) =>
      r.date === null && a.date !== null
        ? 1
        : a.date === null && r.date !== null
          ? -1
          : (r.date !== null && a.date !== null ? s * (r.date - a.date) : 0) ||
            r.index - a.index,
    )
    .map((r) => r.record);
}
function C({ onSearch: i }) {
  const [l, s] = c.useState('');
  function r(a) {
    (a.preventDefault(), i(l.trim()));
  }
  return e.jsxs('section', {
    className: 'memorial-index-hero',
    dir: 'rtl',
    'aria-labelledby': 'memorial-index-title',
    children: [
      e.jsx('div', {
        className: 'memorial-index-hero__backdrop',
        'aria-hidden': 'true',
        children: e.jsx('img', {
          src: './assets/memorial/hero-background.png',
          alt: '',
        }),
      }),
      e.jsxs('div', {
        className: 'memorial-index-container',
        children: [
          e.jsxs('div', {
            className: 'memorial-index-hero__eyebrow',
            children: [
              e.jsx('img', { src: './assets/live/eyebrow-line.svg', alt: '' }),
              e.jsx('span', { children: 'یادبود ها' }),
              e.jsx('img', { src: './assets/live/eyebrow-line.svg', alt: '' }),
            ],
          }),
          e.jsx('h1', {
            id: 'memorial-index-title',
            children: 'یاد عزیزانی که همیشه در خاطر ما هستند',
          }),
          e.jsx('p', {
            children: 'آرشیوی برای گرامی‌داشت خاطرات و یاد عزیزان',
          }),
          e.jsxs('form', {
            className: 'memorial-index-search',
            role: 'search',
            'aria-label': 'جستجوی یادبود',
            onSubmit: r,
            children: [
              e.jsx('input', {
                type: 'search',
                name: 'query',
                'aria-label': 'جستجو بر اساس نام',
                placeholder: 'جستجو بر اساس نام...',
                value: l,
                onChange: (a) => s(a.currentTarget.value),
              }),
              e.jsx('button', { type: 'submit', children: 'جستجو' }),
            ],
          }),
        ],
      }),
    ],
  });
}
g('memorial');
function h(i) {
  if (i === 'memorial') {
    window.scrollTo({ top: 0 });
    return;
  }
  if (b(i)) {
    d(i);
    return;
  }
  window.dispatchEvent(
    new CustomEvent('tarhim:navigate', { detail: { target: i } }),
  );
}
function M(i) {
  if (i === 'ceremonies') {
    h('live');
    return;
  }
  ['services', 'archive', 'plans'].includes(i) && d('home', i);
}
function o(i, l = {}) {
  window.dispatchEvent(new CustomEvent(`tarhim:${i}`, { detail: l }));
}
function E() {
  const [i, l] = c.useState(''),
    [s, r] = c.useState('newest');
  return e.jsxs('main', {
    className: 'memorial-index-page',
    children: [
      e.jsx(p, { onNavigate: h, currentTarget: 'memorial' }),
      e.jsx(C, {
        onSearch: (a) => {
          (l(a), o('search-memorials', { query: a }));
        },
      }),
      e.jsx(_, {
        resetKey: `${s}:${i}`,
        records: k(w(N, i), s),
        onView: (a) => {
          (o('open-memorial', { memorialId: a }), d('memorialPost'));
        },
        onLoadMore: () => o('load-memorials'),
        sortOrder: s,
        onSort: (a) => {
          (r(a), o('sort-memorials', { order: a }));
        },
      }),
      e.jsx(v, {
        onQuickLink: M,
        onService: (a) => o('service-details', { serviceId: a }),
        onSocial: (a) => o('social', { platform: a }),
      }),
    ],
  });
}
j.createRoot(document.getElementById('root')).render(
  e.jsx(c.StrictMode, { children: e.jsx(E, {}) }),
);
