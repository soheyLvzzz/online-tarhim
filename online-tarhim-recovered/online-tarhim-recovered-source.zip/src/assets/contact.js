import {
  r as d,
  j as s,
  i as g,
  c as p,
  H as v,
  F as u,
  a as f,
  n as l,
} from './routes.js';
/* empty css               */ const x = './assets/contact/email-button.svg',
  h = './assets/contact/eyebrow-line.svg',
  _ = [
    {
      label: 'تلفن',
      value: '021 - 88645157',
      href: 'tel:02188645157',
      icon: './assets/contact/form/phone-info.svg',
    },
    {
      label: 'ایمیل',
      value: 'online.tarhim@gmail.com',
      href: 'mailto:online.tarhim@gmail.com',
      icon: x,
    },
    {
      label: 'اینستاگرام',
      value: '@Online.tarhim',
      href: 'https://www.instagram.com/online.tarhim/',
      icon: './assets/contact/form/instagram.svg',
    },
    {
      label: 'واتساپ',
      value: '09153675475',
      href: 'https://wa.me/989153675475',
      icon: './assets/contact/form/whatsapp.svg',
    },
  ];
function o({
  name: e,
  label: t,
  icon: c,
  type: a = 'text',
  multiline: n = !1,
}) {
  return s.jsxs('label', {
    className: `contact-field${n ? ' contact-field--message' : ''}`,
    children: [
      s.jsx('img', { src: c, alt: '' }),
      n
        ? s.jsx('textarea', {
            name: e,
            required: !0,
            'aria-label': t,
            placeholder: ' ',
          })
        : s.jsx('input', {
            name: e,
            type: a,
            required: !0,
            'aria-label': t,
            placeholder: ' ',
          }),
      s.jsxs('span', {
        className: 'contact-field__hint',
        'aria-hidden': 'true',
        children: [t, ' ', s.jsx('span', { children: '*' })],
      }),
    ],
  });
}
function b() {
  const [e, t] = d.useState(!1);
  function c(a) {
    (a.preventDefault(), t(!0));
  }
  return s.jsxs('section', {
    className: 'contact-message contact-container',
    id: 'contact-message',
    'aria-labelledby': 'contact-message-title',
    children: [
      s.jsxs('div', {
        className: 'contact-message__hours',
        children: [
          s.jsx('img', { src: h, alt: '' }),
          s.jsx('img', { src: './assets/contact/form/clock.svg', alt: '' }),
          s.jsx('span', { children: 'ساعت پاسخگویی : همه روزه 9 تا 21' }),
          s.jsx('img', { src: h, alt: '' }),
        ],
      }),
      s.jsxs('div', {
        className: 'contact-message__grid',
        children: [
          s.jsxs('form', {
            className: 'contact-message__form',
            onSubmit: c,
            onChange: () => t(!1),
            children: [
              s.jsxs('h2', {
                id: 'contact-message-title',
                children: [
                  'اطلاعات سفارش دهنده ',
                  s.jsx('img', {
                    src: './assets/contact/form/heading-line.svg',
                    alt: '',
                  }),
                ],
              }),
              s.jsxs('div', {
                className: 'contact-message__fields',
                children: [
                  s.jsx(o, {
                    name: 'name',
                    label: 'نام و نام خانوادگی',
                    icon: './assets/contact/form/person.svg',
                  }),
                  s.jsx(o, {
                    name: 'phone',
                    label: 'شماره تماس',
                    icon: './assets/contact/form/phone-input.svg',
                    type: 'tel',
                  }),
                  s.jsx(o, {
                    name: 'topic',
                    label: 'موضوع پیام',
                    icon: './assets/contact/form/topic.svg',
                  }),
                  s.jsx(o, {
                    name: 'message',
                    label: 'متن پیام',
                    icon: x,
                    multiline: !0,
                  }),
                ],
              }),
              s.jsxs('button', {
                className: 'contact-message__submit',
                type: 'submit',
                children: [
                  'ادامه و ورود به مرحله بعد ',
                  s.jsx('img', {
                    src: './assets/contact/form/arrow.svg',
                    alt: '',
                  }),
                ],
              }),
              e &&
                s.jsx('p', {
                  className: 'contact-message__status',
                  role: 'status',
                  children:
                    'فرم برای تست آماده است. ارسال پیام در این نسخه فعال نیست.',
                }),
            ],
          }),
          s.jsxs('aside', {
            className: 'contact-message__information',
            'aria-labelledby': 'contact-information-title',
            children: [
              s.jsx('h2', {
                id: 'contact-information-title',
                children: 'اطلاعات ارتباطی',
              }),
              s.jsx('p', {
                children:
                  'تیم آنلاین ترحیم برای همراهی و پاسخ گویی در کنار شماست',
              }),
              s.jsx('dl', {
                children: _.map((a) =>
                  s.jsxs(
                    'div',
                    {
                      className: 'contact-message__channel',
                      children: [
                        s.jsxs('dt', {
                          children: [
                            s.jsx('img', { src: a.icon, alt: '' }),
                            a.label,
                            ' :',
                          ],
                        }),
                        s.jsx('dd', {
                          children: s.jsx('a', {
                            href: a.href,
                            dir: 'ltr',
                            children: a.value,
                          }),
                        }),
                      ],
                    },
                    a.label,
                  ),
                ),
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
const w = [
  {
    question: 'چگونه می توانم مراسم آنلاین برگزار کنم ؟',
    answer:
      'از بخش «درخواست برگزاری مجلس» شروع کنید. برای هماهنگی زمان مراسم و انتخاب خدمات می‌توانید با تیم پشتیبانی تماس بگیرید.',
    icon: './assets/contact/faq/arrow-first.svg',
  },
  {
    question: 'چطور وارد مراسم شوم ؟',
    answer:
      'از لینک دعوتی که برگزارکننده در اختیارتان گذاشته استفاده کنید یا مراسم را در بخش «مراسم های درحال اجرا» پیدا کنید.',
    icon: './assets/contact/faq/arrow.svg',
  },
  {
    question: 'آیا امکان طراحی صفحه یادبود وجود دارد ؟',
    answer:
      'بله. طراحی صفحه یادبود از خدمات آنلاین ترحیم است. برای هماهنگی جزئیات صفحه با تیم پشتیبانی در ارتباط باشید.',
    icon: './assets/contact/faq/arrow.svg',
  },
  {
    question: 'چه زمانی پاسخ پیام من داده می شود ؟',
    answer:
      'ساعت پاسخ‌گویی تیم آنلاین ترحیم هر روز از ۹ تا ۲۱ است. برای پیگیری پیام می‌توانید در همین بازه تماس بگیرید.',
    icon: './assets/contact/faq/arrow.svg',
  },
];
function N() {
  const [e, t] = d.useState(null);
  return s.jsxs('section', {
    className: 'contact-faq contact-container',
    'aria-labelledby': 'contact-faq-title',
    children: [
      s.jsxs('div', {
        className: 'contact-faq__eyebrow',
        children: [
          s.jsx('span', { children: 'سوالات شما' }),
          s.jsx('img', { src: './assets/contact/eyebrow-line.svg', alt: '' }),
        ],
      }),
      s.jsx('h2', { id: 'contact-faq-title', children: 'پرسش های متداول' }),
      s.jsx('div', {
        className: 'contact-faq__items',
        children: w.map(({ question: c, answer: a, icon: n }, i) => {
          const r = e === i,
            m = `contact-faq-answer-${i}`;
          return s.jsxs(
            'div',
            {
              className: 'contact-faq__item',
              'data-open': r,
              children: [
                s.jsxs('button', {
                  className: 'contact-faq__toggle',
                  type: 'button',
                  'aria-expanded': r,
                  'aria-controls': m,
                  onClick: () => t((j) => (j === i ? null : i)),
                  children: [
                    s.jsx('span', { children: c }),
                    s.jsx('img', { src: n, alt: '' }),
                  ],
                }),
                s.jsx('div', {
                  className: 'contact-faq__answer',
                  id: m,
                  inert: !r,
                  children: s.jsx('div', {
                    className: 'contact-faq__answer-inner',
                    children: s.jsx('p', { children: a }),
                  }),
                }),
              ],
            },
            c,
          );
        }),
      }),
    ],
  });
}
const q = [
  {
    id: 'phone',
    title: 'تماس تلفنی',
    description: 'مشاوره و راهنمایی مستقیم در زمینه برگزاری مراسم',
    value: '021 - 88645157',
    href: 'tel:02188645157',
    icon: 'phone-card.svg',
  },
  {
    id: 'whatsapp',
    title: 'واتساپ',
    description: 'پاسخ گویی سریع و دریافت راهنمایی از طریق واتساپ',
    value: '09153673075',
    href: 'https://wa.me/989153673075',
    icon: 'whatsapp-card.svg',
  },
  {
    id: 'email',
    title: 'ایمیل',
    description: 'ارسال پرسش ها ، درخواست ها و دریافت اطلاعات بیشتر',
    value: 'online.tarhim@gmail.com',
    href: 'mailto:online.tarhim@gmail.com',
    icon: 'email-button.svg',
  },
];
function y() {
  return s.jsxs('section', {
    className: 'contact-hero',
    dir: 'rtl',
    'aria-labelledby': 'contact-title',
    children: [
      s.jsxs('div', {
        className: 'contact-hero__backdrop',
        'aria-hidden': 'true',
        children: [
          s.jsx('div', {
            className: 'contact-hero__crop',
            children: s.jsx('img', {
              src: './assets/contact/hero-background.png',
              alt: '',
            }),
          }),
          s.jsx('span', {}),
        ],
      }),
      s.jsxs('div', {
        className: 'contact-container',
        children: [
          s.jsxs('div', {
            className: 'contact-hero__heading',
            children: [
              s.jsxs('div', {
                className: 'contact-hero__eyebrow',
                children: [
                  s.jsx('img', {
                    src: './assets/contact/eyebrow-line.svg',
                    alt: '',
                  }),
                  s.jsx('span', { children: 'تماس با ما' }),
                  s.jsx('img', {
                    src: './assets/contact/eyebrow-line.svg',
                    alt: '',
                  }),
                ],
              }),
              s.jsx('h1', {
                id: 'contact-title',
                children: 'در کنار شما هستیم',
              }),
              s.jsxs('p', {
                children: [
                  'برای دریافت مشاوره ، راهنمایی خدمات و پاسخ به پرسش هایتان ،',
                  s.jsx('br', {}),
                  'با ما در ارتباط باشید .',
                ],
              }),
              s.jsxs('div', {
                className: 'contact-hero__actions',
                children: [
                  s.jsxs('a', {
                    className: 'contact-hero__call',
                    href: 'tel:02188645157',
                    children: [
                      s.jsx('img', {
                        src: './assets/contact/phone-button.svg',
                        alt: '',
                      }),
                      s.jsx('span', { children: 'تماس تلفنی' }),
                    ],
                  }),
                  s.jsxs('button', {
                    type: 'button',
                    className: 'contact-hero__message',
                    onClick: () =>
                      document
                        .getElementById('contact-message')
                        ?.scrollIntoView(),
                    children: [
                      s.jsx('span', {
                        className: 'contact-hero__envelope',
                        children: s.jsx('img', {
                          src: './assets/contact/email-button.svg',
                          alt: '',
                        }),
                      }),
                      s.jsx('span', { children: 'ارسال پیام' }),
                    ],
                  }),
                ],
              }),
            ],
          }),
          s.jsx('div', {
            className: 'contact-hero__cards',
            children: q.map((e) =>
              s.jsxs(
                'a',
                {
                  className: 'contact-card',
                  href: e.href,
                  target: e.id === 'whatsapp' ? '_blank' : void 0,
                  rel: e.id === 'whatsapp' ? 'noopener noreferrer' : void 0,
                  'aria-labelledby': `contact-${e.id}-title`,
                  'aria-describedby': `contact-${e.id}-description contact-${e.id}-value`,
                  children: [
                    s.jsx('span', {
                      className: 'contact-card__art',
                      'aria-hidden': 'true',
                      children: s.jsx('img', {
                        src: './assets/contact/card-background.png',
                        alt: '',
                      }),
                    }),
                    s.jsxs('div', {
                      className: 'contact-card__body',
                      children: [
                        s.jsxs('span', {
                          className: 'contact-card__icon',
                          'aria-hidden': 'true',
                          children: [
                            s.jsx('img', {
                              className: 'contact-card__circle',
                              src: './assets/contact/icon-circle.svg',
                              alt: '',
                            }),
                            s.jsx('img', {
                              className: 'contact-card__symbol',
                              src: `./assets/contact/${e.icon}`,
                              alt: '',
                            }),
                          ],
                        }),
                        s.jsx('h2', {
                          id: `contact-${e.id}-title`,
                          children: e.title,
                        }),
                        s.jsx('p', {
                          id: `contact-${e.id}-description`,
                          children: e.description,
                        }),
                        s.jsx('div', {
                          className: 'contact-card__divider',
                          'aria-hidden': 'true',
                          children: s.jsx('img', {
                            src: './assets/contact/card-divider.svg',
                            alt: '',
                          }),
                        }),
                        s.jsx('div', {
                          className: 'contact-card__value',
                          id: `contact-${e.id}-value`,
                          children: s.jsx('bdi', {
                            dir: 'ltr',
                            children: e.value,
                          }),
                        }),
                      ],
                    }),
                  ],
                },
                e.id,
              ),
            ),
          }),
        ],
      }),
    ],
  });
}
g('contact');
function E(e) {
  if (e === 'contact') {
    window.scrollTo({ top: 0 });
    return;
  }
  if (f(e)) {
    l(e);
    return;
  }
  window.dispatchEvent(
    new CustomEvent('tarhim:navigate', { detail: { target: e } }),
  );
}
function C(e) {
  if (e === 'ceremonies') {
    l('live');
    return;
  }
  ['services', 'archive', 'plans'].includes(e) && l('home', e);
}
p.createRoot(document.getElementById('root')).render(
  s.jsx(d.StrictMode, {
    children: s.jsxs('main', {
      className: 'contact-page',
      children: [
        s.jsx(v, { onNavigate: E, currentTarget: 'contact' }),
        s.jsx(y, {}),
        s.jsx(b, {}),
        s.jsx(N, {}),
        s.jsx(u, {
          onQuickLink: C,
          onService: (e) =>
            window.dispatchEvent(
              new CustomEvent('tarhim:service-details', {
                detail: { serviceId: e },
              }),
            ),
          onSocial: (e) =>
            window.dispatchEvent(
              new CustomEvent('tarhim:social', { detail: { platform: e } }),
            ),
        }),
      ],
    }),
  }),
);
