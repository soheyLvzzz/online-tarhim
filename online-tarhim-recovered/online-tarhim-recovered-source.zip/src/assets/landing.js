import {
  j as e,
  r as n,
  u as d,
  i as b,
  c as p,
  H as g,
  F as N,
  a as w,
  n as f,
} from './routes.js';
import { u as j, M as u } from './MobileCarouselControls.js';
function y({ onRequestCeremony: s, onViewLiveCeremonies: a }) {
  return e.jsxs('section', {
    className: 'memorial-hero',
    lang: 'fa',
    dir: 'rtl',
    'aria-labelledby': 'hero-title',
    'data-node-id': '4:35',
    children: [
      e.jsxs('div', {
        className: 'section-backdrop',
        'aria-hidden': 'true',
        children: [
          e.jsx('img', {
            className: 'memorial-hero__background',
            src: './assets/hero-candles.jpg',
            alt: '',
          }),
          e.jsx('div', { className: 'memorial-hero__shade' }),
        ],
      }),
      e.jsxs('div', {
        className: 'memorial-hero__content',
        children: [
          e.jsxs('div', {
            className: 'memorial-hero__eyebrow',
            children: [
              e.jsx('span', {
                children: 'برگزاری محترمانه مجالس ترحیم و بزرگداشت',
              }),
              e.jsx('img', {
                src: './assets/eyebrow-line.svg',
                alt: '',
                'aria-hidden': 'true',
              }),
            ],
          }),
          e.jsxs('h1', {
            id: 'hero-title',
            children: [
              'یاد عزیزانتان را ،',
              e.jsx('br', {}),
              'با احترام گرامی بدارید .',
            ],
          }),
          e.jsx('p', {
            className: 'memorial-hero__description',
            children:
              'برگزاری آنلاین مراسم ترحیم و یادبود، همراه با خدمات تخصصی از انتخاب مجری و مداح تا پخش زنده مراسم، تا خانواده‌ها و عزیزانشان بتوانند از هر فاصله‌ای در کنار یکدیگر باشند و یاد درگذشتگان خود را گرامی بدارند.',
          }),
          e.jsxs('div', {
            className: 'memorial-hero__actions',
            children: [
              e.jsx('button', {
                className:
                  'memorial-hero__button memorial-hero__button--primary',
                onClick: s,
                type: 'button',
                children: 'درخواست برگزاری مراسم',
              }),
              e.jsx('button', {
                className:
                  'memorial-hero__button memorial-hero__button--secondary',
                onClick: a,
                type: 'button',
                children: 'مراسم های درحال اجرا',
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
function E() {
  const s = n.useRef(null),
    [a, l] = n.useState('visible');
  return (
    n.useEffect(() => {
      const i = s.current,
        r = window.matchMedia('(prefers-reduced-motion: reduce)');
      if (!i || r.matches || !('IntersectionObserver' in window)) return;
      l('pending');
      const c = new IntersectionObserver(
        ([_]) => {
          _?.isIntersecting && (l('entered'), c.disconnect());
        },
        { threshold: 0.12 },
      );
      c.observe(i);
      const h = () => {
        r.matches && (l('visible'), c.disconnect());
      };
      return (
        r.addEventListener('change', h),
        () => {
          (c.disconnect(), r.removeEventListener('change', h));
        }
      );
    }, []),
    e.jsxs('section', {
      ref: s,
      className: 'memorial-about',
      lang: 'fa',
      dir: 'rtl',
      'aria-labelledby': 'about-title',
      'data-node-id': '21:229',
      'data-reveal': a,
      children: [
        e.jsxs('div', {
          className: 'section-backdrop',
          'aria-hidden': 'true',
          children: [
            e.jsx('img', {
              className: 'memorial-about__background',
              src: './assets/about-background.jpg',
              alt: '',
            }),
            e.jsx('div', { className: 'memorial-about__shade' }),
          ],
        }),
        e.jsxs('div', {
          className: 'memorial-about__content',
          children: [
            e.jsxs('div', {
              className: 'memorial-about__eyebrow',
              'data-node-id': '4:214',
              children: [
                e.jsx('span', { children: 'درباره آنلاین ترحیم' }),
                e.jsx('img', {
                  src: './assets/eyebrow-line.svg',
                  alt: '',
                  'aria-hidden': 'true',
                }),
              ],
            }),
            e.jsx('h2', {
              id: 'about-title',
              children: 'همراه شما، حتی در فاصله‌ها',
            }),
            e.jsx('p', {
              className: 'memorial-about__intro',
              children:
                'آنلاین ترحیم با هدف فراهم‌کردن امکان برگزاری مراسم یادبود به‌صورت آنلاین شکل گرفته است تا خانواده‌ها و عزیزانشان، حتی زمانی که امکان حضور در کنار یکدیگر را ندارند، بتوانند در لحظات سوگواری و یادبود همراه هم باشند.',
            }),
            e.jsx('p', {
              className: 'memorial-about__details',
              children:
                'ما تلاش می‌کنیم با فراهم‌کردن بستری ساده و قابل‌اعتماد برای هماهنگی مراسم، انتخاب مداح و مجری، پخش زنده و دعوت از مهمانان، شرایطی فراهم کنیم تا خانواده‌ها با آرامش بیشتری مراسم عزیزان خود را برگزار کنند. باور داریم فاصله‌ها نباید مانع همدلی، همدردی و زنده نگه‌داشتن یاد عزیزانمان شوند.',
            }),
            e.jsx('p', {
              className: 'memorial-about__closing',
              children: 'فاصله ها ، مانع همدلی نیستند.',
            }),
          ],
        }),
      ],
    })
  );
}
const o = [
  {
    id: 'simple',
    title: 'مراسم ساده',
    description:
      'مناسب برای برگزاری مجالس یادبود صمیمی و خانوادگی با امکانات اصلی پخش و اطلاع‌رسانی.',
    features: [
      'اختصاص صفحه یادبود و لینک دعوت اختصاصی',
      'حضور مداح یا قاری منتخب',
      'پخش آنلاین مراسم با کیفیت استاندارد',
      'طراحی پوستر و اعلامیه یادبود دیجیتال',
      'ثبت پیام‌های تسلیت مهمانان در دفتر یادبود',
    ],
    price: '2.400.000',
  },
  {
    id: 'special',
    title: 'مراسم ویژه',
    description:
      'پکیج کامل میزبانی مراسم ترحیم با حضور مجری، مداح، تدوین ویدیوی خاطرات و آرشیو دائمی.',
    features: [
      'کارگردانی و پخش آنلاین چنددوربینه',
      'طراحی اختصاصی پوستر یادبود و دعوت‌نامه',
      'تدوین ویدیوی یادبود از تصاویر و خاطرات',
      'آرشیو کامل ویدیویی مراسم و پیام‌های تسلیت',
      'پشتیبانی و هماهنگی اختصاصی در تمام مراحل',
    ],
    price: '4.500.000',
  },
  {
    id: 'custom',
    title: 'مراسم اختصاصی',
    description:
      'برنامه‌ریزی کاملاً سفارشی برای مجالس بزرگداشت، پوشش همزمان مراسم حضوری و خدمات ویژه.',
    features: [
      'انتخاب اساتید، سخنرانان و مداحان برجسته کشوری',
      'امکان پوشش تصویری از محل برگزاری مورد نظر شما',
      'تولید مستند کوتاه یادبود و بسته‌های گرافیکی کامل',
      'مدیریت دعوت و اطلاع‌رسانی اختصاصی به مهمانان',
      'نگهداری ماندگار در آرشیو اختصاصی با حریم خصوصی',
    ],
    price: '8.100.000',
  },
];
function k({ plan: s, onRequest: a }) {
  return e.jsxs('article', {
    className: 'plan-card',
    'aria-labelledby': `plan-${s.id}`,
    children: [
      s.id === 'special' &&
        e.jsx('span', {
          className: 'plan-card__badge',
          children: 'انتخاب متداول خانواده ها',
        }),
      e.jsx('h3', { id: `plan-${s.id}`, children: s.title }),
      e.jsx('p', {
        className: 'plan-card__description',
        children: s.description,
      }),
      e.jsx('div', { className: 'plan-card__divider', 'aria-hidden': 'true' }),
      e.jsx('ul', {
        className: 'plan-card__features',
        children: s.features.map((l) =>
          e.jsxs(
            'li',
            {
              children: [
                e.jsx('img', {
                  src: './assets/plan-bullet.svg',
                  alt: '',
                  'aria-hidden': 'true',
                }),
                e.jsx('span', { children: l }),
              ],
            },
            l,
          ),
        ),
      }),
      e.jsxs('div', {
        className: 'plan-card__price',
        children: [
          e.jsx('span', { children: 'قیمت :' }),
          e.jsxs('strong', {
            children: [
              e.jsx('bdi', { dir: 'ltr', children: s.price }),
              'تومان',
            ],
          }),
        ],
      }),
      e.jsx('button', {
        className: 'plan-card__request',
        type: 'button',
        onClick: () => a(s.id),
        'aria-label': `درخواست ${s.title}`,
        children: 'درخواست این مراسم',
      }),
    ],
  });
}
function C({ onRequestPlan: s }) {
  const { sectionRef: a, reveal: l } = d(),
    i = j(o.length);
  return e.jsxs('section', {
    ref: a,
    id: 'plans',
    className: 'memorial-plans',
    lang: 'fa',
    dir: 'rtl',
    'aria-labelledby': 'plans-title',
    'data-node-id': '4:114',
    'data-reveal': l,
    children: [
      e.jsxs('div', {
        className: 'memorial-plans__heading',
        children: [
          e.jsxs('div', {
            className: 'memorial-plans__eyebrow',
            children: [
              e.jsx('img', { src: './assets/eyebrow-line.svg', alt: '' }),
              e.jsx('span', { children: 'انتخاب پلن مراسم' }),
              e.jsx('img', { src: './assets/eyebrow-line.svg', alt: '' }),
            ],
          }),
          e.jsx('h2', { id: 'plans-title', children: 'پلن های مراسم' }),
        ],
      }),
      e.jsx('div', {
        className: 'memorial-plans__grid mobile-carousel-track',
        id: 'plans-carousel',
        ref: i.trackRef,
        onScroll: i.sync,
        onKeyDown: i.onKeyDown,
        tabIndex: i.mobile ? 0 : void 0,
        role: i.mobile ? 'group' : void 0,
        'aria-label': i.mobile ? 'پلن مراسم' : void 0,
        children: o.map((r) => e.jsx(k, { plan: r, onRequest: s }, r.id)),
      }),
      e.jsx(u, {
        id: 'plans-carousel',
        label: 'پلن مراسم',
        index: i.index,
        count: o.length,
        onGo: i.go,
      }),
    ],
  });
}
const R = [
  {
    id: 'ceremony',
    icon: './assets/service-ceremony.svg',
    title: 'برگزاری مراسم ترحیم',
    description:
      'برنامه‌ریزی و اجرای کامل مجالس ختم، سوم، هفتم، چهلم و سالگرد با رعایت کامل آداب اصیل ایرانی و اسلامی در فضایی آرام و درخور شأن.',
  },
  {
    id: 'host',
    icon: './assets/service-host.svg',
    title: 'انتخاب مجری و مداح',
    description:
      'امکان انتخاب از میان قاریان، سخنرانان و مداحان خوش‌نام و باسابقه متناسب با سلیقه، فرهنگ و سنت خانوادگی شما.',
  },
  {
    id: 'live',
    icon: './assets/service-live.svg',
    title: 'پخش آنلاین مراسم',
    description:
      'پوشش تصویری و صوتی پایدار با لینک اختصاصی دعوت، جهت حضور آسان اقوام و دوستانی که در شهرها یا کشورهای دیگر سکونت دارند.',
  },
  {
    id: 'poster',
    icon: './assets/service-poster.svg',
    title: 'طراحی پوستر یادبود',
    description:
      'طراحی اختصاصی اعلامیه ترحیم، کتیبه و دعوت‌نامه دیجیتال با تایپوگرافی فاخر فارسی و صفحه‌آرایی متین برای ارسال به بستگان.',
  },
  {
    id: 'video',
    icon: './assets/service-video.svg',
    title: 'تدوین ویدیوی یادبود',
    description:
      'ساخت و تدوین فیلم کوتاه زندگی‌نامه و مرور خاطرات ارزشمند از تصاویر و فیلم‌های خانوادگی، جهت پخش در جریان مراسم.',
  },
  {
    id: 'archive',
    icon: './assets/service-archive.svg',
    title: 'آرشیو و نگهداری مراسم',
    description:
      'ضبط کامل مراسم، گردآوری پیام‌های تسلیت مهمانان و نگهداری امن در صفحه یادبود اختصاصی به عنوان یادگاری ماندگار برای خانواده.',
  },
];
function $({ service: s, onMore: a }) {
  return e.jsxs('article', {
    className: 'service-card',
    'aria-labelledby': `service-${s.id}`,
    children: [
      e.jsxs('div', {
        className: 'service-card__icon',
        'aria-hidden': 'true',
        children: [
          e.jsx('img', {
            className: 'service-card__icon-frame',
            src: './assets/service-icon-frame.svg',
            alt: '',
          }),
          e.jsx('img', {
            className: 'service-card__icon-symbol',
            src: s.icon,
            alt: '',
          }),
        ],
      }),
      e.jsx('h3', { id: `service-${s.id}`, children: s.title }),
      e.jsx('p', { children: s.description }),
      e.jsxs('div', {
        className: 'service-card__more-row',
        children: [
          e.jsx('button', {
            type: 'button',
            className: 'service-card__more',
            onClick: () => a(s.id),
            'aria-label': `اطلاعات بیشتر دربارهٔ ${s.title}`,
            children: 'اطلاعات بیشتر',
          }),
          e.jsx('img', {
            src: './assets/service-arrow.svg',
            alt: '',
            'aria-hidden': 'true',
          }),
        ],
      }),
    ],
  });
}
function S({ onMore: s }) {
  const { sectionRef: a, reveal: l } = d();
  return e.jsxs('section', {
    ref: a,
    id: 'services',
    className: 'memorial-services',
    lang: 'fa',
    dir: 'rtl',
    'aria-labelledby': 'services-title',
    'data-node-id': '4:211',
    'data-reveal': l,
    children: [
      e.jsxs('div', {
        className: 'memorial-services__heading',
        children: [
          e.jsxs('div', {
            className: 'memorial-services__eyebrow',
            children: [
              e.jsx('span', { children: 'خدمات تکمیلی یادبود' }),
              e.jsx('img', { src: './assets/eyebrow-line.svg', alt: '' }),
            ],
          }),
          e.jsx('h2', { id: 'services-title', children: 'سایر خدمات' }),
        ],
      }),
      e.jsx('div', {
        className: 'memorial-services__grid',
        children: R.map((i) => e.jsx($, { service: i, onMore: s }, i.id)),
      }),
    ],
  });
}
const m = ['ceremony-1', 'ceremony-2', 'ceremony-3', 'ceremony-4'];
function I({ onView: s }) {
  const { sectionRef: a, reveal: l } = d(),
    i = j(m.length);
  return e.jsxs('section', {
    ref: a,
    id: 'archive',
    className: 'memorial-archive',
    lang: 'fa',
    dir: 'rtl',
    'aria-labelledby': 'archive-title',
    'data-node-id': '51:284',
    'data-reveal': l,
    children: [
      e.jsxs('div', {
        className: 'memorial-archive__heading',
        children: [
          e.jsxs('div', {
            className: 'memorial-archive__eyebrow',
            children: [
              e.jsx('img', { src: './assets/eyebrow-line.svg', alt: '' }),
              e.jsx('span', { children: 'آرشیو مجالس' }),
              e.jsx('img', { src: './assets/eyebrow-line.svg', alt: '' }),
            ],
          }),
          e.jsx('h2', {
            id: 'archive-title',
            children: 'یادهایی که همیشه زنده‌اند',
          }),
        ],
      }),
      e.jsx('div', {
        className: 'memorial-archive__grid mobile-carousel-track',
        id: 'archive-carousel',
        ref: i.trackRef,
        onScroll: i.sync,
        onKeyDown: i.onKeyDown,
        tabIndex: i.mobile ? 0 : void 0,
        role: i.mobile ? 'group' : void 0,
        'aria-label': i.mobile ? 'آرشیو مجالس' : void 0,
        children: m.map((r, c) =>
          e.jsxs(
            'article',
            {
              className: 'archive-card',
              'aria-labelledby': `archive-${r}`,
              children: [
                e.jsxs('div', {
                  className: 'archive-card__media',
                  children: [
                    e.jsx('img', {
                      className: 'archive-card__image',
                      src: './assets/memorial/post/portrait.png',
                      alt: '',
                    }),
                    e.jsxs('span', {
                      className: 'archive-card__year archive-card__year--birth',
                      children: [
                        'سال تولد',
                        e.jsx('strong', { children: '۱۳۴۸' }),
                      ],
                    }),
                    e.jsxs('span', {
                      className: 'archive-card__year archive-card__year--death',
                      children: [
                        'سال فوت',
                        e.jsx('strong', { children: '۱۴۰۴' }),
                      ],
                    }),
                    e.jsx('span', {
                      className: 'archive-card__badge',
                      children: 'آرشیو مراسم',
                    }),
                  ],
                }),
                e.jsxs('div', {
                  className: 'archive-card__content',
                  children: [
                    e.jsx('h3', {
                      id: `archive-${r}`,
                      children: 'مراسم یادبود مرحوم محمد رضایی',
                    }),
                    e.jsx('p', { children: '۱۴ آبان ۱۴۰۵' }),
                    e.jsx('div', {
                      className: 'archive-card__divider',
                      'aria-hidden': 'true',
                    }),
                    e.jsxs('button', {
                      type: 'button',
                      className: 'archive-card__view',
                      onClick: () => s(r),
                      'aria-label': `مشاهده مراسم یادبود ${c + 1}`,
                      children: [
                        e.jsx('span', { children: 'مشاهده مراسم' }),
                        e.jsx('img', {
                          src: './assets/archive-play.svg',
                          alt: '',
                        }),
                      ],
                    }),
                  ],
                }),
              ],
            },
            r,
          ),
        ),
      }),
      e.jsx(u, {
        id: 'archive-carousel',
        label: 'آرشیو مجالس',
        index: i.index,
        count: m.length,
        onGo: i.go,
      }),
    ],
  });
}
const q = [
  {
    id: 'remembrance-traditions',
    category: 'فرهنگ و آیین',
    title: 'آیین‌های یادبود؛ راهی برای زنده نگه داشتن خاطرات',
  },
  {
    id: 'digital-memorial',
    category: 'راهنمای خانواده',
    title: 'چطور صفحه یادبود دیجیتال بسازیم؟',
  },
  {
    id: 'platform-updates',
    category: 'اخبار مجموعه',
    title: 'تازه‌ترین امکانات سامانه آنلاین ترحیم',
  },
];
function v({ id: s, title: a, onRead: l }) {
  return e.jsxs('button', {
    className: 'news-read',
    type: 'button',
    onClick: () => l(s),
    'aria-label': `مطالعه مقالهٔ ${a}`,
    children: [
      e.jsx('span', { children: 'مطالعه مقاله' }),
      e.jsx('img', { src: './assets/service-arrow.svg', alt: '' }),
    ],
  });
}
function M({ onRead: s }) {
  const { sectionRef: a, reveal: l } = d(),
    i = 'چگونه مراسم یادبود را به‌صورت آنلاین برگزار کنیم؟';
  return e.jsxs('section', {
    ref: a,
    className: 'memorial-news',
    lang: 'fa',
    dir: 'rtl',
    'aria-labelledby': 'news-title',
    'data-node-id': '72:458',
    'data-reveal': l,
    children: [
      e.jsxs('div', {
        className: 'memorial-news__heading',
        children: [
          e.jsxs('div', {
            className: 'memorial-news__eyebrow',
            children: [
              e.jsx('span', { children: 'آخرین اخبار' }),
              e.jsx('img', { src: './assets/eyebrow-line.svg', alt: '' }),
            ],
          }),
          e.jsx('h2', { id: 'news-title', children: 'اخبار آنلاین ترحیم' }),
        ],
      }),
      e.jsxs('div', {
        className: 'memorial-news__grid',
        children: [
          e.jsxs('article', {
            className: 'news-featured',
            'aria-labelledby': 'featured-title',
            children: [
              e.jsx('img', {
                className: 'news-featured__image',
                src: './assets/news-candles.jpg',
                alt: 'شمع‌های روشن یادبود',
              }),
              e.jsxs('div', {
                className: 'news-featured__meta',
                children: [
                  e.jsx('span', { children: 'راهنمای برگزاری' }),
                  e.jsx('span', {
                    className: 'news-featured__date',
                    children: e.jsx('bdi', {
                      dir: 'ltr',
                      children: '1405/08/12',
                    }),
                  }),
                ],
              }),
              e.jsx('h3', { id: 'featured-title', children: i }),
              e.jsx('p', {
                children:
                  'راهنمایی برای برگزاری مراسمی محترمانه و فراهم کردن امکان همراهی عزیزان از هر نقطه.',
              }),
              e.jsx(v, { id: 'online-ceremony-guide', title: i, onRead: s }),
            ],
          }),
          e.jsx('div', {
            className: 'memorial-news__list',
            children: q.map((r) =>
              e.jsxs(
                'article',
                {
                  className: 'news-item',
                  'aria-labelledby': `news-${r.id}`,
                  children: [
                    e.jsx('p', {
                      className: 'news-item__category',
                      children: r.category,
                    }),
                    e.jsx('h3', { id: `news-${r.id}`, children: r.title }),
                    e.jsx(v, { id: r.id, title: r.title, onRead: s }),
                  ],
                },
                r.id,
              ),
            ),
          }),
        ],
      }),
    ],
  });
}
const P = [
  {
    id: 'ceremonies',
    value: '1001',
    label: 'برگزاری مراسم',
    icon: 'ceremonies.svg',
  },
  {
    id: 'simultaneous',
    value: '10',
    label: 'مراسم به صورت همزمان',
    icon: 'simultaneous.svg',
  },
  { id: 'years', value: '7', label: 'سال حضور مستمر', icon: 'years.svg' },
];
function x({ value: s }) {
  return e.jsxs('span', {
    className: 'memorial-record__number',
    dir: 'ltr',
    'aria-label': `${s}+`,
    children: [
      e.jsx('bdi', { dir: 'ltr', children: s }),
      e.jsx('span', {
        className: 'memorial-record__plus',
        'aria-hidden': 'true',
        children: '+',
      }),
    ],
  });
}
function L() {
  return e.jsxs('section', {
    className: 'memorial-record',
    lang: 'fa',
    dir: 'rtl',
    'aria-labelledby': 'record-title',
    'data-node-id': '228:547',
    children: [
      e.jsxs('div', {
        className: 'memorial-record__heading',
        children: [
          e.jsxs('div', {
            className: 'memorial-record__eyebrow',
            children: [
              e.jsx('img', {
                src: './assets/record/eyebrow-line.svg',
                alt: '',
              }),
              e.jsx('span', { children: 'افتخارات آنلاین ترحیم' }),
              e.jsx('img', {
                src: './assets/record/eyebrow-line.svg',
                alt: '',
              }),
            ],
          }),
          e.jsx('h2', { id: 'record-title', children: 'کارنامه آنلاین ترحیم' }),
          e.jsx('p', {
            children: 'سال ها تجربه هزاران همراه و صدها مراسم برگزار شده .',
          }),
        ],
      }),
      e.jsxs('dl', {
        className: 'memorial-record__statistics',
        children: [
          e.jsxs('div', {
            className: 'memorial-record__stat memorial-record__stat--guests',
            children: [
              e.jsxs('dt', {
                children: [
                  e.jsxs('span', {
                    className: 'memorial-record__art',
                    'aria-hidden': 'true',
                    children: [
                      e.jsx('img', {
                        src: './assets/record/guests-candles.png',
                        alt: '',
                      }),
                      e.jsx('span', { className: 'memorial-record__shade' }),
                    ],
                  }),
                  e.jsx('span', {
                    className: 'memorial-record__label',
                    children: 'نفر مهمان',
                  }),
                  e.jsx('img', {
                    className: 'memorial-record__guest-line',
                    src: './assets/record/guest-line.svg',
                    alt: '',
                  }),
                  e.jsx('span', {
                    className: 'memorial-record__description',
                    children: 'همراهی در مراسم های آنلاین',
                  }),
                ],
              }),
              e.jsx('dd', { children: e.jsx(x, { value: '200.000' }) }),
            ],
          }),
          P.map((s) =>
            e.jsxs(
              'div',
              {
                className: `memorial-record__stat memorial-record__stat--${s.id}`,
                children: [
                  e.jsxs('dt', {
                    children: [
                      e.jsx('img', {
                        className: 'memorial-record__icon',
                        src: `./assets/record/${s.icon}`,
                        alt: '',
                      }),
                      e.jsx('span', {
                        className: 'memorial-record__stat-line',
                        'aria-hidden': 'true',
                        children: e.jsx('img', {
                          src: './assets/record/stat-line.svg',
                          alt: '',
                        }),
                      }),
                      e.jsx('span', {
                        className: 'memorial-record__label',
                        children: s.label,
                      }),
                    ],
                  }),
                  e.jsx('dd', { children: e.jsx(x, { value: s.value }) }),
                ],
              },
              s.id,
            ),
          ),
        ],
      }),
    ],
  });
}
b('home');
function t(s) {
  if (s === 'home') {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    return;
  }
  if (w(s)) {
    f(s);
    return;
  }
  window.dispatchEvent(
    new CustomEvent('tarhim:navigate', { detail: { target: s } }),
  );
}
function A(s) {
  if (s === 'ceremonies') {
    t('live');
    return;
  }
  const a = {
    services: '.memorial-services',
    archive: '.memorial-archive',
    plans: '.memorial-plans',
  };
  if (!a[s]) return;
  document
    .querySelector(a[s])
    ?.scrollIntoView({
      behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches
        ? 'instant'
        : 'smooth',
      block: 'start',
    });
}
function D() {
  return (
    n.useEffect(() => {
      const s = window.location.hash.slice(1);
      ['services', 'archive', 'plans'].includes(s) &&
        document
          .getElementById(s)
          ?.scrollIntoView({ behavior: 'instant', block: 'start' });
    }, []),
    null
  );
}
p.createRoot(document.getElementById('root')).render(
  e.jsx(n.StrictMode, {
    children: e.jsxs('main', {
      className: 'landing-preview',
      children: [
        e.jsx(D, {}),
        e.jsx(g, { onNavigate: t }),
        e.jsx(y, {
          onRequestCeremony: () => t('request'),
          onViewLiveCeremonies: () => t('live'),
        }),
        e.jsx(E, {}),
        e.jsx(C, {
          onRequestPlan: (s) =>
            window.dispatchEvent(
              new CustomEvent('tarhim:request-plan', { detail: { planId: s } }),
            ),
        }),
        e.jsx(S, {
          onMore: (s) =>
            window.dispatchEvent(
              new CustomEvent('tarhim:service-details', {
                detail: { serviceId: s },
              }),
            ),
        }),
        e.jsx(I, {
          onView: (s) =>
            window.dispatchEvent(
              new CustomEvent('tarhim:view-archive', {
                detail: { ceremonyId: s },
              }),
            ),
        }),
        e.jsx(M, {
          onRead: (s) =>
            window.dispatchEvent(
              new CustomEvent('tarhim:read-article', {
                detail: { articleId: s },
              }),
            ),
        }),
        e.jsx(L, {}),
        e.jsx(N, {
          onQuickLink: A,
          onService: (s) =>
            window.dispatchEvent(
              new CustomEvent('tarhim:service-details', {
                detail: { serviceId: s },
              }),
            ),
          onSocial: (s) =>
            window.dispatchEvent(
              new CustomEvent('tarhim:social', { detail: { platform: s } }),
            ),
        }),
      ],
    }),
  }),
);
