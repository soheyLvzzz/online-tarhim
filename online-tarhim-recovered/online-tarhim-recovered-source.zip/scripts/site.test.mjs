import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { resolve, sep } from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { test } from 'node:test';
import { SourceTextModule } from 'node:vm';
import { JSDOM, VirtualConsole } from 'jsdom';

const routes = JSON.parse(await readFile('routes.json', 'utf8'));
const baseline = JSON.parse(await readFile('baseline.json', 'utf8'));
const selectors = {
  'index.html': '.memorial-hero h1',
  'live.html': '.live-card',
  'memorial.html': '.memorial-index-search input',
  'memorial-post.html': '#memorial-post-title',
  'request.html': '.request-form input',
  'contact.html': '#contact-title',
  'blog.html': '.blog-featured a.blog-read__button',
  'blog-guide.html': '#guide-related-title',
};

for (const [directory, environment] of [['dist', 'production'], ['dist-staging', 'staging']]) {
  test(environment + ' manifest covers all eight pages and the recovered public media', async () => {
    const manifest = JSON.parse(await readFile(directory + '/health.json', 'utf8'));
    assert.equal(manifest.environment, environment);
    assert.equal(manifest.assets.length, baseline.assets.length);
    const assets = new Map(manifest.assets.map(item => [item.path, item.sha256]));
    for (const item of baseline.assets.filter(item => !/\.(js|css|html)$/.test(item.path))) {
      assert.equal(assets.get(item.path), item.sha256, item.path);
    }
    for (const [file, slug] of Object.entries(routes)) {
      const direct = await readFile(directory + '/' + file, 'utf8');
      const canonical = await readFile(directory + '/' + slug + '/index.html', 'utf8');
      assert.equal(canonical.replace('\n    <base href="../" />', ''), direct);
      assert.equal(direct.includes('name="robots"'), environment === 'staging');
    }
  });
}

async function render(file, directory) {
  const staging = directory === 'dist-staging';
  const slug = routes[file];
  const html = await readFile(directory + '/' + slug + '/index.html', 'utf8');
  const prefix = staging ? '/staging/' : '/';
  const url = new URL(prefix + encodeURIComponent(slug) + '/', 'https://example.test');
  const virtualConsole = new VirtualConsole();
  const errors = [];
  virtualConsole.on('jsdomError', error => errors.push(error));
  virtualConsole.on('error', error => errors.push(error));
  const dom = new JSDOM(html, { url: url.href, runScripts: 'outside-only', pretendToBeVisual: true, virtualConsole });
  const { window } = dom;
  window.matchMedia = () => ({ matches: false, addEventListener() {}, removeEventListener() {} });
  window.ResizeObserver = class { observe() {} unobserve() {} disconnect() {} };
  window.scrollTo = () => {};
  window.HTMLElement.prototype.scrollTo = () => {};
  window.HTMLElement.prototype.scrollIntoView = () => {};
  window.HTMLElement.prototype.hasPointerCapture = () => false;
  window.HTMLElement.prototype.setPointerCapture = () => {};
  window.HTMLElement.prototype.releasePointerCapture = () => {};
  const create = window.document.createElement.bind(window.document);
  window.document.createElement = (...args) => {
    const el = create(...args);
    if (args[0] === 'link') el.relList.supports = () => true;
    return el;
  };

  const root = resolve(directory);
  const modules = new Map();
  async function getModule(path) {
    if (!path.startsWith(root + sep)) throw Error('Module escaped the release directory: ' + path);
    if (!modules.has(path)) {
      modules.set(path, readFile(path, 'utf8').then(source =>
        new SourceTextModule(source, { context: dom.getInternalVMContext(), identifier: pathToFileURL(path).href })));

    }
    return modules.get(path);
  }
  try {
    const entry = window.document.querySelector('script[type=module][src]');
    assert(entry, file);
    const asset = new URL(entry.src).pathname.slice(prefix.length);
    const entryModule = await getModule(resolve(root, asset));
    await entryModule.link((specifier, parent) => getModule(fileURLToPath(new URL(specifier, parent.identifier))));
    await entryModule.evaluate();
    for (let i = 0; i < 35 && !window.document.querySelector(selectors[file]); i++) await new Promise(done => setTimeout(done, 15));
    assert.deepEqual(errors.map(error => String(error)), []);
    assert(window.document.querySelector(selectors[file]), file + ' did not render its main content');
    return dom;
  } catch (error) {
    window.close();
    throw error;
  }
}

for (const file of Object.keys(routes)) {
  test('recovered page renders in staging: ' + file, async () => {
    const dom = await render(file, 'dist-staging');
    const doc = dom.window.document;
    try {
      if (file === 'blog.html') {
        assert.equal(doc.querySelectorAll('.blog-card').length, 9);
        assert.equal(decodeURIComponent(new URL(doc.querySelector(selectors[file]).href).pathname), '/staging/راهنمای-برگزاری-مراسم-آنلاین/');
      }
      if (file === 'blog-guide.html') {
        assert.equal(doc.querySelectorAll('.guide-section').length, 5);
        assert.equal(doc.querySelectorAll('.guide-related .blog-card').length, 3);
      }
      if (file === 'request.html') {
        assert.equal(doc.querySelectorAll('.request-steps li').length, 4);
        assert.equal(doc.querySelectorAll('button[role=combobox]').length, 2);
        const trigger = doc.querySelector('button[role=combobox]');
        trigger.dispatchEvent(new dom.window.KeyboardEvent('keydown', { key: 'ArrowDown', bubbles: true }));
        for (let i = 0; i < 35 && !doc.querySelector('[role=option]'); i++) await new Promise(done => setTimeout(done, 15));
        assert.equal(doc.querySelectorAll('[role=option]').length, 4);
      }
    } finally {
      dom.window.close();
    }
  });
}
