import { cp, mkdir, readdir, readFile, rm, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { dirname, extname, join, posix, relative, resolve, sep } from 'node:path';

const environment = process.argv[2] || 'production';
if (!['production', 'staging'].includes(environment)) throw Error('Expected production or staging');
const output = environment === 'staging' ? 'dist-staging' : 'dist';
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const json = async name => JSON.parse(await readFile(name, 'utf8'));
const routes = await json('routes.json');
const fragments = await json('fragments.json');
const reserved = new Set(Object.values(fragments).flat().filter(path => path.startsWith('src/assets/')).map(path => posix.basename(path)));
const entries = new Set([
  ...Object.keys(fragments),
  ...(await readdir('src/assets')).filter(name => /\.(js|css)$/.test(name) && !reserved.has(name)),
]);

const bundles = new Map();
const visiting = new Set();
async function bundle(name) {
  if (bundles.has(name)) return bundles.get(name);
  if (!entries.has(name)) throw Error('Missing module: ' + name);
  if (visiting.has(name)) throw Error('Circular module dependency: ' + name);
  visiting.add(name);

  const parts = fragments[name] || [join('src/assets', name)];
  let text = (await Promise.all(parts.map(path => readFile(path, 'utf8')))).join('\n');
  if (name.endsWith('.js')) {
    const imports = [...text.matchAll(/\b(?:from\s*|import\s*(?:\(\s*)?)["']\.\/([^"'\/]+\.js)["']/g)];
    for (const dependency of new Set(imports.map(match => match[1]))) {
      const result = await bundle(dependency);
      text = text.replaceAll('./' + dependency, './' + result.filename);
    }
  }

  const extension = extname(name);
  const filename = name.slice(0, -extension.length) + '-' + sha(text).slice(0, 12) + extension;
  const result = { filename, text };
  bundles.set(name, result);
  visiting.delete(name);
  return result;
}

for (const name of [...entries].sort()) await bundle(name);
await rm(output, { recursive: true, force: true });
await cp('public', output, { recursive: true });
await mkdir(join(output, 'assets'), { recursive: true });
for (const { filename, text } of bundles.values()) await writeFile(join(output, 'assets', filename), text);

for (const [file, slug] of Object.entries(routes)) {
  let html = await readFile(join('src/pages', file), 'utf8');
  for (const [logical, { filename }] of bundles) html = html.replaceAll('./assets/' + logical, './assets/' + filename);
  if (environment === 'staging') {
    html = html.replace('<meta name="description"', '<meta name="robots" content="noindex, nofollow" />\n    <meta name="description"');
  }
  await writeFile(join(output, file), html);
  const pretty = html.replace(/(<meta\s+charset=[^>]+>)/i, '$1\n    <base href="../" />');
  await mkdir(join(output, slug), { recursive: true });
  await writeFile(join(output, slug, 'index.html'), pretty);
}

const publicRoot = resolve(output);
const files = new Map();
async function collect(folder) {
  for (const entry of await readdir(folder, { withFileTypes: true })) {
    const path = join(folder, entry.name);
    if (entry.isSymbolicLink()) throw Error('Symlink in release: ' + path);
    if (entry.isDirectory()) await collect(path);
    if (entry.isFile()) {
      const name = relative(publicRoot, path).split(sep).join('/');
      if (/\/(?:\.git|node_modules|\.env)(?:\/|$)/i.test('/' + name) || /\.(?:zip|bak|sql|map)$/i.test(name)) {
        throw Error('Unexpected public file: ' + name);
      }
      files.set(name, await readFile(path));
    }
  }
}
await collect(publicRoot);

function checkReference(owner, ref, base = '') {
  if (ref.startsWith('data:') || ref.startsWith('#')) return;
  const pathname = decodeURIComponent(ref.split(/[?#]/, 1)[0]);
  const target = pathname.startsWith('/') ? resolve(publicRoot, '.' + pathname) : resolve(publicRoot, dirname(owner), base, pathname);
  const name = relative(publicRoot, target).split(sep).join('/');
  if (!target.startsWith(publicRoot + sep) || !files.has(name)) throw Error('Missing reference from ' + owner + ': ' + ref);
}

for (const [name, bytes] of files) {
  const text = /\.(?:html|css|js)$/.test(name) ? bytes.toString('utf8') : '';
  if (name.endsWith('.html')) {
    const base = /<base\s+href="([^"]+)"/.exec(text)?.[1] || '';
    if ((environment === 'staging') !== /<meta\s+name="robots"[^>]*noindex/.test(text)) throw Error('Unexpected robots setting: ' + name);
    for (const [, ref] of text.replace(/<base\b[^>]*>/g, '').matchAll(/\b(?:src|href)="([^"]+)"/g)) checkReference(name, ref, base);
  }
  if (name.endsWith('.css')) {
    for (const [, ref] of text.matchAll(/url\(([^)]+)\)/g)) checkReference(name, ref.trim().replace(/^['"]|['"]$/g, ''));
  }
  if (name.endsWith('.js')) {
    for (const [, ref] of text.matchAll(/\b(?:from\s*|import\s*(?:\(\s*)?)["'](\.\/[^"']+\.js)["']/g)) checkReference(name, ref);
    for (const [, ref] of text.matchAll(/["'](\.\/assets\/[^"']+)["']/g)) checkReference('index.html', ref);
  }
}

const assets = [...files].sort(([a], [b]) => a.localeCompare(b)).map(([path, bytes]) => ({ path, bytes: bytes.length, sha256: sha(bytes) }));
const manifest = { schemaVersion: 1, service: 'online-tarhim-landing', mode: 'static', environment, buildId: sha(JSON.stringify(assets)).slice(0, 16), assets };
await writeFile(join(output, 'health.json'), JSON.stringify(manifest, null, 2) + '\n');
console.log(JSON.stringify({ environment, output, buildId: manifest.buildId, files: assets.length }));
